package com.joyram.cleaner

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.joyram.cleaner.domain.model.Insight
import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.Severity
import com.joyram.cleaner.domain.model.TimePoint
import com.joyram.cleaner.ui.components.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import com.joyram.cleaner.ui.theme.JoyTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ComponentsUiTest {
    @get:Rule val rule = createComposeRule()
    private val ctx get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test fun chartExplainsWhenThereIsNotEnoughData() {
        rule.setContent { JoyTheme(darkTheme = true) { LineChart(listOf(TimePoint(0, 1f))) } }
        rule.onNodeWithText(ctx.getString(R.string.chart_collecting)).assertIsDisplayed()
    }

    @Test fun insightCardShowsTitleBodyAndSuggestion() {
        val insight = Insight(
            InsightId.STORAGE_LOW, Severity.WARNING,
            R.string.ins_storage_low_title, R.string.ins_storage_low_body, R.string.ins_storage_action, listOf(15),
        )
        rule.setContent { JoyTheme(darkTheme = false) { InsightCard(insight) } }
        rule.onNodeWithText(ctx.getString(R.string.ins_storage_low_title)).assertIsDisplayed()
        rule.onNodeWithText(ctx.getString(R.string.ins_storage_low_body, 15)).assertIsDisplayed()
    }

    @Test fun emptyStateShowsItsMessage() {
        rule.setContent {
            JoyTheme(darkTheme = true) { EmptyState(Icons.Filled.Apps, "Nothing here") }
        }
        rule.onNodeWithText("Nothing here").assertIsDisplayed()
    }

    @Test fun gaugeShowsItsValue() {
        rule.setContent { JoyTheme(darkTheme = true) { GaugeRing(73, "health") } }
        rule.onNodeWithText("73").assertIsDisplayed()
        rule.onNodeWithText("health").assertIsDisplayed()
    }
}
