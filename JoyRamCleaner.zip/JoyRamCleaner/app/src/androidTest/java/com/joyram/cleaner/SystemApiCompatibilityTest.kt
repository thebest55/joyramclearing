package com.joyram.cleaner

import android.os.Build
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.joyram.cleaner.data.system.AppsSource
import com.joyram.cleaner.data.system.SystemMetricsSource
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Runs against the real device or emulator APIs, on whichever Android version it has. */
@RunWith(AndroidJUnit4::class)
class SystemApiCompatibilityTest {
    private lateinit var source: SystemMetricsSource
    private lateinit var apps: AppsSource

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        source = SystemMetricsSource(ctx)
        apps = AppsSource(ctx)
    }

    @Test fun ramValuesAreConsistent() {
        val r = source.readRam()
        assertTrue(r.totalBytes > 0)
        assertTrue(r.availBytes in 0..r.totalBytes)
        assertTrue(r.usedPercent in 0..100)
        assertTrue(r.appPssBytes > 0)
    }

    @Test fun storageValuesAreConsistent() {
        val s = source.readStorage()
        assertTrue(s.totalBytes > 0)
        assertTrue(s.freeBytes in 0..s.totalBytes)
        assertEquals(100, s.usedPercent + s.freePercent)
    }

    @Test fun batteryValuesAreInRange() {
        val b = source.readBattery()
        assertTrue(b.levelPercent in 0..100)
        assertTrue(b.voltageMv >= 0)
        assertTrue(b.tempC > -30f && b.tempC < 120f)
    }

    @Test fun cpuReportsHonestly() {
        source.readCpu()
        Thread.sleep(300)
        val c = source.readCpu()
        assertTrue(c.cores >= 1)
        assertTrue(c.model.isNotBlank())
        c.usagePercent?.let { assertTrue(it in 0..100) }
        // thermal status is only available from Android 10; below that it must be null, never invented
        if (Build.VERSION.SDK_INT < 29) assertNull(c.thermalStatus)
    }

    @Test fun deviceDetailsMatchBuild() {
        val d = source.readDeviceDetails()
        assertEquals(Build.VERSION.SDK_INT, d.sdk)
        assertEquals(Build.MODEL, d.model)
        assertTrue(d.uptimeMs > 0)
        assertTrue(d.resolution.contains("x"))
        assertTrue(d.densityDpi > 0)
    }

    @Test fun ownCacheClearingReportsRealBytes() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        val f = java.io.File(ctx.cacheDir, "joy_test_cache.bin")
        f.writeBytes(ByteArray(4096))
        val before = source.ownCacheSize()
        assertTrue(before >= 4096)
        val freed = source.clearOwnCache()
        assertTrue(freed >= 4096)
        assertFalse(f.exists())
    }

    @Test fun appListContainsThisApp() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        val list = apps.load()
        assertTrue(list.isNotEmpty())
        val me = list.firstOrNull { it.packageName == ctx.packageName }
        assertNotNull("the app must see itself", me)
        assertFalse(me!!.isSystem)
        assertTrue(me.apkSizeBytes > 0)
    }
}
