package com.joyram.cleaner

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.joyram.cleaner.data.db.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DatabaseTest {
    private lateinit var db: JoyDatabase

    @Before fun create() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), JoyDatabase::class.java)
            .allowMainThreadQueries().build()
    }

    @After fun close() { db.close() }

    @Test fun recordAllWritesAllFourHistoryTables() = runBlocking {
        val h = db.historyDao()
        h.recordAll(
            RamHistoryEntity(timestamp = 100, totalBytes = 1000, availBytes = 400, usedPercent = 60),
            CpuHistoryEntity(timestamp = 100, usagePercent = -1, appCpuPercent = 1, avgFreqMhz = 1800),
            BatteryHistoryEntity(timestamp = 100, level = 80, tempC = 31.5f, voltageMv = 4000, charging = false),
            StorageHistoryEntity(timestamp = 100, totalBytes = 1000, freeBytes = 300),
        )
        assertEquals(1, h.ram(0).first().size)
        assertEquals(-1, h.cpu(0).first().first().usagePercent)
        assertEquals(31.5f, h.battery(0).first().first().tempC, 0.001f)
        assertEquals(300L, h.storage(0).first().first().freeBytes)
    }

    @Test fun sinceFilterAndOrdering() = runBlocking {
        val h = db.historyDao()
        listOf(300L, 100L, 200L).forEach { h.insertRam(RamHistoryEntity(timestamp = it, totalBytes = 1, availBytes = 1, usedPercent = 10)) }
        assertEquals(listOf(100L, 200L, 300L), h.ram(0).first().map { it.timestamp })
        assertEquals(listOf(200L, 300L), h.ram(150).first().map { it.timestamp })
    }

    @Test fun pruneAllRemovesOnlyOldRows() = runBlocking {
        val h = db.historyDao()
        h.insertRam(RamHistoryEntity(timestamp = 10, totalBytes = 1, availBytes = 1, usedPercent = 1))
        h.insertRam(RamHistoryEntity(timestamp = 500, totalBytes = 1, availBytes = 1, usedPercent = 1))
        h.insertScan(ScanHistoryEntity(timestamp = 10, healthScore = 90, issueCount = 0, durationMs = 5))
        h.pruneAll(100)
        assertEquals(listOf(500L), h.ram(0).first().map { it.timestamp })
        assertTrue(h.scans(10).first().isEmpty())
        h.pruneAll(Long.MAX_VALUE)
        assertTrue(h.ram(0).first().isEmpty())
    }

    @Test fun reportsCanBeFilteredByType() = runBlocking {
        val h = db.historyDao()
        fun report(type: String, t: Long) = PerformanceReportEntity(
            timestamp = t, type = type, healthScore = 80, ramPercent = 50, storageFreePercent = 40, batteryTempC = 30f,
            batteryLevel = 70, cpuPercent = -1, issueIds = "", refPackage = null, durationMs = 0, ramPercentStart = 0, tempStartC = 0f,
        )
        h.insertReport(report("SCAN", 1)); h.insertReport(report("GAME", 2)); h.insertReport(report("GAME", 3))
        assertEquals(3, h.allReports(10).first().size)
        assertEquals(listOf(3L, 2L), h.reportsOfType("GAME", 10).first().map { it.timestamp })
    }

    @Test fun settingsRoundTrip() = runBlocking {
        val c = db.catalogDao()
        assertNull(c.getSetting("k"))
        c.putSetting(UserSettingEntity("k", "v1"))
        c.putSetting(UserSettingEntity("k", "v2"))
        assertEquals("v2", c.getSetting("k"))
        assertEquals("v2", c.observeSetting("k").first())
        c.removeSetting("k")
        assertNull(c.getSetting("k"))
    }

    @Test fun replaceAppsReplacesPreviousCatalog() = runBlocking {
        val c = db.catalogDao()
        fun app(pkg: String) = AppInfoEntity(pkg, pkg, "1", false, 1, 1, 10, null, true)
        c.replaceApps(listOf(app("a"), app("b")))
        assertEquals(2, c.apps().size)
        c.replaceApps(listOf(app("c")))
        assertEquals(listOf("c"), c.apps().map { it.packageName })
    }

    @Test fun deviceInfoIsSingleRow() = runBlocking {
        val c = db.catalogDao()
        c.upsertDevice(DeviceInfoEntity(1, "A", "M1", "14", 34, "k", 1))
        c.upsertDevice(DeviceInfoEntity(1, "A", "M2", "14", 34, "k", 2))
        assertEquals("M2", c.device()!!.model)
    }
}
