package com.joyram.cleaner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.joyram.cleaner.data.system.AppsSource
import com.joyram.cleaner.util.MediaPermissions
import com.joyram.cleaner.util.PermissionChecker
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PermissionTest {
    private val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()

    @Test fun requiredMediaPermissionsMatchAndroidVersion() {
        val p = MediaPermissions.required().toList()
        if (Build.VERSION.SDK_INT >= 33) {
            assertEquals(
                setOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO),
                p.toSet(),
            )
        } else {
            assertEquals(listOf(Manifest.permission.READ_EXTERNAL_STORAGE), p)
        }
    }

    @Test fun manifestDoesNotRequestBroadOrDangerousExtras() {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS)
        val declared = info.requestedPermissions.orEmpty().toSet()
        assertFalse(declared.contains("android.permission.QUERY_ALL_PACKAGES"))
        assertFalse(declared.contains(Manifest.permission.INTERNET))
        assertFalse(declared.contains("android.permission.MANAGE_EXTERNAL_STORAGE"))
        assertFalse(declared.contains(Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    @Test fun permissionCheckerMatchesSystemState() {
        val checker = PermissionChecker(ctx, FakeUsage(AppsSource(ctx)))
        val expectedMedia = MediaPermissions.required().all {
            ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
        }
        assertEquals(expectedMedia, checker.mediaGranted())
        assertEquals(AppsSource(ctx).hasUsageAccess(), checker.state().usageAccess)
    }

    private class FakeUsage(private val src: AppsSource) : com.joyram.cleaner.domain.repository.AppsRepository {
        override suspend fun loadApps() = src.load()
        override fun hasUsageAccess() = src.hasUsageAccess()
    }
}
