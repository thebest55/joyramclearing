package com.joyram.cleaner

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.joyram.cleaner.data.db.JoyDatabase
import com.joyram.cleaner.data.repository.HistoryRepositoryImpl
import com.joyram.cleaner.data.settings.SettingsStore
import com.joyram.cleaner.data.system.SystemMetricsSource
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class HistoryRepositoryTest {
    private lateinit var db: JoyDatabase
    private lateinit var repo: HistoryRepositoryImpl
    private lateinit var source: SystemMetricsSource

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, JoyDatabase::class.java).allowMainThreadQueries().build()
        repo = HistoryRepositoryImpl(db.historyDao(), SettingsStore(ctx))
        source = SystemMetricsSource(ctx)
    }

    @After fun tearDown() { db.close() }

    @Test fun recordIsThrottledUnlessForced() = runBlocking {
        val now = System.currentTimeMillis()
        val s = source.readSnapshot().copy(timestamp = now)
        repo.record(s)
        repo.record(s.copy(timestamp = now + 1_000))
        assertEquals(1, repo.ramSeries(0).first().size)
        repo.record(s.copy(timestamp = now + 2_000), force = true)
        assertEquals(2, repo.ramSeries(0).first().size)
    }

    @Test fun recordedValuesMatchTheSnapshot() = runBlocking {
        val s = source.readSnapshot().copy(timestamp = System.currentTimeMillis())
        repo.record(s, force = true)
        assertEquals(s.ram.usedPercent.toFloat(), repo.ramSeries(0).first().first().v, 0.001f)
        assertEquals(s.battery.levelPercent.toFloat(), repo.batteryLevelSeries(0).first().first().v, 0.001f)
    }

    @Test fun clearAllEmptiesEverySeries() = runBlocking {
        repo.record(source.readSnapshot().copy(timestamp = System.currentTimeMillis()), force = true)
        repo.clearAll()
        assertTrue(repo.ramSeries(0).first().isEmpty())
        assertTrue(repo.cpuSeries(0).first().isEmpty())
        assertTrue(repo.batteryTempSeries(0).first().isEmpty())
        assertTrue(repo.storageFreeSeries(0).first().isEmpty())
    }
}
