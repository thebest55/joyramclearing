package com.joyram.cleaner.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "DeviceInfo")
data class DeviceInfoEntity(
    @PrimaryKey val id: Int = 1,
    val brand: String,
    val model: String,
    val androidRelease: String,
    val sdk: Int,
    val kernel: String,
    val updatedAt: Long,
)

@Entity(tableName = "RamHistory", indices = [Index("timestamp")])
data class RamHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val totalBytes: Long,
    val availBytes: Long,
    val usedPercent: Int,
)

@Entity(tableName = "CpuHistory", indices = [Index("timestamp")])
data class CpuHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    /** -1 when the device does not expose a usable measurement */
    val usagePercent: Int,
    val appCpuPercent: Int,
    val avgFreqMhz: Int,
)

@Entity(tableName = "BatteryHistory", indices = [Index("timestamp")])
data class BatteryHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val level: Int,
    val tempC: Float,
    val voltageMv: Int,
    val charging: Boolean,
)

@Entity(tableName = "StorageHistory", indices = [Index("timestamp")])
data class StorageHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val totalBytes: Long,
    val freeBytes: Long,
)

@Entity(tableName = "ScanHistory", indices = [Index("timestamp")])
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val healthScore: Int,
    val issueCount: Int,
    val durationMs: Long,
)

@Entity(tableName = "AppInfo")
data class AppInfoEntity(
    @PrimaryKey val packageName: String,
    val label: String,
    val versionName: String,
    val isSystem: Boolean,
    val installTime: Long,
    val updateTime: Long,
    val apkSizeBytes: Long,
    val lastUsed: Long?,
    val canLaunch: Boolean,
)

@Entity(tableName = "UserSettings")
data class UserSettingEntity(
    @PrimaryKey val name: String,
    val value: String,
)

@Entity(tableName = "PerformanceReport", indices = [Index("timestamp")])
data class PerformanceReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val type: String,
    val healthScore: Int,
    val ramPercent: Int,
    val storageFreePercent: Int,
    val batteryTempC: Float,
    val batteryLevel: Int,
    val cpuPercent: Int,
    val issueIds: String,
    val refPackage: String?,
    val durationMs: Long,
    val ramPercentStart: Int,
    val tempStartC: Float,
)
