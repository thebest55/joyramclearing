package com.joyram.cleaner.data.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import com.joyram.cleaner.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/** Reads real values from Android APIs. Anything the device does not expose is reported as null. */
@Singleton
class SystemMetricsSource @Inject constructor(@ApplicationContext private val ctx: Context) {
    private val am = ctx.getSystemService(ActivityManager::class.java)
    private val pm = ctx.getSystemService(PowerManager::class.java)
    private var prevStat: LongArray? = null
    private var prevCpuTime = Process.getElapsedCpuTime()
    private var prevWall = SystemClock.elapsedRealtime()

    fun readRam(): RamInfo {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val dbg = Debug.MemoryInfo()
        Debug.getMemoryInfo(dbg)
        return RamInfo(mi.totalMem, mi.availMem, mi.threshold, mi.lowMemory, dbg.totalPss * 1024L)
    }

    @Synchronized
    fun readCpu(): CpuInfo {
        val cores = Runtime.getRuntime().availableProcessors()
        val cur = (0 until cores).map { readLong("/sys/devices/system/cpu/cpu$it/cpufreq/scaling_cur_freq") }
        val max = (0 until cores).map { readLong("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq") }

        var usage: Int? = null
        var source = CpuUsageSource.UNAVAILABLE
        val stat = readProcStat()
        if (stat != null) {
            source = CpuUsageSource.PROC_STAT
            prevStat?.let { p ->
                val n = minOf(stat.size, p.size, 8)
                var total = 0L
                for (i in 0 until n) total += stat[i] - p[i]
                val idle = (stat[3] - p[3]) + (if (n > 4) stat[4] - p[4] else 0L)
                if (total > 0) usage = (((total - idle) * 100) / total).toInt().coerceIn(0, 100)
            }
            prevStat = stat
        } else {
            val ratios = cur.indices.mapNotNull { i ->
                val c = cur[i]; val m = max[i]
                if (c != null && m != null && m > 0) c.toDouble() / m else null
            }
            if (ratios.isNotEmpty()) {
                usage = (ratios.average() * 100).toInt().coerceIn(0, 100)
                source = CpuUsageSource.FREQUENCY
            }
        }

        val nowCpu = Process.getElapsedCpuTime()
        val nowWall = SystemClock.elapsedRealtime()
        val wall = nowWall - prevWall
        val appPct = if (wall > 0) (((nowCpu - prevCpuTime) * 100) / (wall * cores)).toInt().coerceIn(0, 100) else 0
        prevCpuTime = nowCpu
        prevWall = nowWall

        val thermal = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else null
        return CpuInfo(
            model = cpuModel(), abi = Build.SUPPORTED_ABIS.firstOrNull().orEmpty(), cores = cores,
            curFreqKhz = cur, maxFreqKhz = max, usagePercent = usage, usageSource = source,
            appCpuPercent = appPct, thermalStatus = thermal, cpuTempC = readCpuTemp(),
        )
    }

    fun readBattery(): BatteryInfo {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val current = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        return BatteryInfo(
            levelPercent = pct,
            tempC = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
            voltageMv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0,
            status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
                ?: BatteryManager.BATTERY_STATUS_UNKNOWN,
            plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0,
            technology = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY).orEmpty(),
            health = i?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
                ?: BatteryManager.BATTERY_HEALTH_UNKNOWN,
            currentNowUa = if (current == Long.MIN_VALUE || current == 0L) null else current,
        )
    }

    fun readStorage(): StorageInfo {
        val st = StatFs(Environment.getDataDirectory().path)
        return StorageInfo(st.totalBytes, st.availableBytes)
    }

    fun readSnapshot(): SystemSnapshot = SystemSnapshot(
        timestamp = System.currentTimeMillis(),
        ram = readRam(), cpu = readCpu(), battery = readBattery(), storage = readStorage(),
        device = DeviceSummary(Build.BRAND, Build.MODEL, Build.VERSION.RELEASE, Build.VERSION.SDK_INT),
    )

    fun readDeviceDetails(): DeviceDetails {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val wm = ctx.getSystemService(WindowManager::class.java)
        val (w, h) = if (Build.VERSION.SDK_INT >= 30) {
            wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
        val display = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        return DeviceDetails(
            brand = Build.BRAND, manufacturer = Build.MANUFACTURER, model = Build.MODEL, product = Build.PRODUCT,
            androidRelease = Build.VERSION.RELEASE, sdk = Build.VERSION.SDK_INT,
            securityPatch = Build.VERSION.SECURITY_PATCH, buildId = Build.DISPLAY, fingerprint = Build.FINGERPRINT,
            kernel = System.getProperty("os.version").orEmpty(),
            abis = Build.SUPPORTED_ABIS.joinToString(", "),
            cpuModel = cpuModel(), cpuCores = Runtime.getRuntime().availableProcessors(),
            ramTotalBytes = readRam().totalBytes,
            glEsVersion = am.deviceConfigurationInfo.glEsVersion.orEmpty(),
            resolution = "$w x $h", densityDpi = ctx.resources.displayMetrics.densityDpi,
            refreshRateHz = display?.refreshRate ?: 0f,
            batteryTechnology = readBattery().technology,
            sensors = sm.getSensorList(Sensor.TYPE_ALL).map { it.name }.distinct().sorted(),
            uptimeMs = SystemClock.elapsedRealtime(),
        )
    }

    fun ownCacheSize(): Long = cacheDirs().sumOf { dirSize(it) }

    fun clearOwnCache(): Long {
        var freed = 0L
        cacheDirs().forEach { dir ->
            dir.listFiles()?.forEach { f ->
                val size = dirSize(f)
                if (f.deleteRecursively()) freed += size
            }
        }
        return freed
    }

    private fun cacheDirs(): List<File> = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)

    private fun dirSize(f: File): Long =
        if (f.isFile) f.length() else f.listFiles()?.sumOf { dirSize(it) } ?: 0L

    private fun cpuModel(): String {
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != Build.UNKNOWN) {
            return "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim()
        }
        try {
            File("/proc/cpuinfo").useLines { lines ->
                lines.firstOrNull { it.startsWith("Hardware") || it.startsWith("model name") }
                    ?.substringAfter(':')?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
            }
        } catch (_: Exception) { }
        return Build.HARDWARE
    }

    private fun readProcStat(): LongArray? = try {
        File("/proc/stat").bufferedReader().use { it.readLine() }?.let { line ->
            if (!line.startsWith("cpu ")) null
            else line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                .toLongArray().takeIf { it.size >= 4 }
        }
    } catch (_: Exception) { null }

    private fun readText(f: File): String? = try { f.readText().trim() } catch (_: Exception) { null }

    private fun readLong(path: String): Long? = readText(File(path))?.toLongOrNull()

    private fun readCpuTemp(): Float? {
        val zones = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") } ?: return null
        for (z in zones.sortedBy { it.name }) {
            val type = readText(File(z, "type")) ?: continue
            if (type.contains("cpu", true) || type.contains("soc", true) || type.contains("tsens", true)) {
                val raw = readText(File(z, "temp"))?.toFloatOrNull() ?: continue
                val c = if (raw > 1000f) raw / 1000f else raw
                if (c in 1f..120f) return c
            }
        }
        return null
    }
}
