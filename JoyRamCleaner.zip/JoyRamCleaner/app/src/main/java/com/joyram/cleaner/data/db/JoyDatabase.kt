package com.joyram.cleaner.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        DeviceInfoEntity::class, RamHistoryEntity::class, CpuHistoryEntity::class, BatteryHistoryEntity::class,
        StorageHistoryEntity::class, ScanHistoryEntity::class, AppInfoEntity::class, UserSettingEntity::class,
        PerformanceReportEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class JoyDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun catalogDao(): CatalogDao
}
