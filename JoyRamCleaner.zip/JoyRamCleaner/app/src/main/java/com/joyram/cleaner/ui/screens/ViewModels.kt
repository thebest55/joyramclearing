@file:OptIn(ExperimentalCoroutinesApi::class)

package com.joyram.cleaner.ui.screens

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.joyram.cleaner.data.settings.AppSettings
import com.joyram.cleaner.data.settings.SettingsStore
import com.joyram.cleaner.data.settings.ThemeMode
import com.joyram.cleaner.domain.analysis.AnalysisEngine
import com.joyram.cleaner.domain.model.*
import com.joyram.cleaner.domain.repository.*
import com.joyram.cleaner.domain.usecase.ScanSystemUseCase
import com.joyram.cleaner.util.PermissionChecker
import com.joyram.cleaner.util.PermissionState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

internal fun <T> Flow<T>.stateInVm(vm: ViewModel, initial: T): StateFlow<T> =
    stateIn(vm.viewModelScope, SharingStarted.WhileSubscribed(5000), initial)

/** Live (foreground) metrics + history series. Sampling stops when no screen observes it. */
@HiltViewModel
class MetricsViewModel @Inject constructor(
    private val system: SystemRepository,
    private val history: HistoryRepository,
) : ViewModel() {
    val live: StateFlow<List<SystemSnapshot>> = system.snapshotFlow(2000)
        .onEach { history.record(it) }
        .runningFold(emptyList<SystemSnapshot>()) { acc, s -> (acc + s).takeLast(60) }
        .stateInVm(this, emptyList())

    private val range = MutableStateFlow(HistoryRange.H1)
    val selectedRange: StateFlow<HistoryRange> = range.asStateFlow()
    fun setRange(r: HistoryRange) { range.value = r }

    private fun series(f: (Long) -> Flow<List<TimePoint>>): StateFlow<List<TimePoint>> =
        range.flatMapLatest { f(System.currentTimeMillis() - it.ms) }.stateInVm(this, emptyList())

    val ramSeries = series(history::ramSeries)
    val cpuSeries = series(history::cpuSeries)
    val levelSeries = series(history::batteryLevelSeries)
    val tempSeries = series(history::batteryTempSeries)
    val storageSeries = series(history::storageFreeSeries)

    private val _cache = MutableStateFlow(0L)
    val cacheBytes: StateFlow<Long> = _cache.asStateFlow()
    private val _freed = MutableStateFlow<Long?>(null)
    val freedBytes: StateFlow<Long?> = _freed.asStateFlow()

    init { refreshCache() }
    fun refreshCache() { viewModelScope.launch { _cache.value = system.ownCacheSize() } }
    fun clearCache() {
        viewModelScope.launch {
            _freed.value = system.clearOwnCache()
            _cache.value = system.ownCacheSize()
        }
    }
    fun dismissFreed() { _freed.value = null }
}

sealed interface ScanUi {
    data object Idle : ScanUi
    data class Running(val stage: ScanStage) : ScanUi
    data class Done(val result: ScanResult) : ScanUi
    data object Failed : ScanUi
}

@HiltViewModel
class HomeViewModel @Inject constructor(
    system: SystemRepository,
    history: HistoryRepository,
    private val scan: ScanSystemUseCase,
) : ViewModel() {
    val snapshot: StateFlow<SystemSnapshot?> = system.snapshotFlow(3000).stateInVm(this, null)
    val lastScan: StateFlow<ScanRecord?> = history.latestScan().stateInVm(this, null)
    private val _scan = MutableStateFlow<ScanUi>(ScanUi.Idle)
    val scanState: StateFlow<ScanUi> = _scan.asStateFlow()

    fun startScan() {
        if (_scan.value is ScanUi.Running) return
        viewModelScope.launch {
            _scan.value = ScanUi.Running(ScanStage.SNAPSHOT)
            try {
                val r = scan(persist = true, onStage = { _scan.value = ScanUi.Running(it) })
                _scan.value = ScanUi.Done(r)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _scan.value = ScanUi.Failed
            }
        }
    }

    fun dismiss() { _scan.value = ScanUi.Idle }
}

enum class FileSort { SIZE, NAME, DATE }
enum class FileFilter { ALL, JUNK, DUPLICATES }

data class StorageUi(
    val storage: StorageInfo? = null,
    val media: MediaSummary? = null,
    val mediaFiles: List<StoredFile> = emptyList(),
    val treeFiles: List<StoredFile> = emptyList(),
    val scanning: Boolean = false,
    val selected: Set<String> = emptySet(),
    val sort: FileSort = FileSort.SIZE,
    val filter: FileFilter = FileFilter.ALL,
    val deleted: Int? = null,
)

@HiltViewModel
class StorageViewModel @Inject constructor(
    private val system: SystemRepository,
    private val repo: StorageRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(StorageUi())
    val ui: StateFlow<StorageUi> = _ui.asStateFlow()

    init { refreshCapacity() }

    fun refreshCapacity() {
        viewModelScope.launch { _ui.update { it.copy(storage = system.snapshot().storage) } }
    }

    fun loadMedia() {
        viewModelScope.launch {
            val summary = repo.mediaSummary()
            val files = repo.largestMedia(100)
            _ui.update { it.copy(media = summary, mediaFiles = files) }
        }
    }

    fun scanFolder(uri: Uri) {
        viewModelScope.launch {
            _ui.update { it.copy(scanning = true) }
            val files = try { repo.scanTree(uri) } catch (e: CancellationException) { throw e } catch (e: Exception) { emptyList() }
            _ui.update { it.copy(scanning = false, treeFiles = files) }
        }
    }

    fun toggle(f: StoredFile) = _ui.update {
        it.copy(selected = if (f.key in it.selected) it.selected - f.key else it.selected + f.key)
    }
    fun clearSelection() = _ui.update { it.copy(selected = emptySet()) }
    fun setSort(s: FileSort) = _ui.update { it.copy(sort = s) }
    fun setFilter(f: FileFilter) = _ui.update { it.copy(filter = f) }
    fun dismissDeleted() = _ui.update { it.copy(deleted = null) }

    fun deleteTreeFiles(files: List<StoredFile>) {
        viewModelScope.launch {
            val n = repo.deleteDocuments(files)
            val keys = files.map { it.key }.toSet()
            _ui.update { s ->
                s.copy(
                    treeFiles = s.treeFiles.filterNot { it.key in keys },
                    selected = s.selected - keys,
                    deleted = n,
                )
            }
            refreshCapacity()
        }
    }

    fun onMediaDeleted(count: Int) {
        _ui.update { it.copy(selected = emptySet(), deleted = count) }
        loadMedia()
        refreshCapacity()
    }
}

enum class AppFilter { USER, SYSTEM, ALL, UNUSED }
enum class AppSort { NAME, SIZE, INSTALL, LAST_USED }

data class AppsUi(
    val loading: Boolean = true,
    val apps: List<AppEntry> = emptyList(),
    val query: String = "",
    val filter: AppFilter = AppFilter.USER,
    val sort: AppSort = AppSort.NAME,
    val usageAccess: Boolean = false,
) {
    val visible: List<AppEntry>
        get() {
            val now = System.currentTimeMillis()
            val day = 86_400_000L
            val base = when (filter) {
                AppFilter.USER -> apps.filter { !it.isSystem }
                AppFilter.SYSTEM -> apps.filter { it.isSystem }
                AppFilter.ALL -> apps
                AppFilter.UNUSED -> apps.filter {
                    !it.isSystem && now - it.installTime > 30 * day && (it.lastUsed == null || now - it.lastUsed > 30 * day)
                }
            }.filter { query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true) }
            return when (sort) {
                AppSort.NAME -> base.sortedBy { it.label.lowercase() }
                AppSort.SIZE -> base.sortedByDescending { it.apkSizeBytes }
                AppSort.INSTALL -> base.sortedByDescending { it.installTime }
                AppSort.LAST_USED -> base.sortedBy { it.lastUsed ?: 0L }
            }
        }
}

@HiltViewModel
class AppsViewModel @Inject constructor(private val repo: AppsRepository) : ViewModel() {
    private val _ui = MutableStateFlow(AppsUi())
    val ui: StateFlow<AppsUi> = _ui.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true) }
            val list = try { repo.loadApps() } catch (e: CancellationException) { throw e } catch (e: Exception) { emptyList() }
            _ui.update { it.copy(loading = false, apps = list, usageAccess = repo.hasUsageAccess()) }
        }
    }

    fun setQuery(q: String) = _ui.update { it.copy(query = q) }
    fun setFilter(f: AppFilter) = _ui.update { it.copy(filter = f) }
    fun setSort(s: AppSort) = _ui.update { it.copy(sort = s) }
}

internal const val KEY_GAMES = "game_packages"
internal const val KEY_SESSION = "game_session"

@HiltViewModel
class GameViewModel @Inject constructor(
    private val appsRepo: AppsRepository,
    private val system: SystemRepository,
    private val catalog: CatalogRepository,
    private val history: HistoryRepository,
    private val scan: ScanSystemUseCase,
) : ViewModel() {
    val apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val loading = MutableStateFlow(true)

    val selected: StateFlow<Set<String>> = catalog.observeSetting(KEY_GAMES)
        .map { s -> s?.split(',')?.filter { it.isNotBlank() }?.toSet() ?: emptySet() }
        .stateInVm(this, emptySet())

    val session: StateFlow<GameSession?> = catalog.observeSetting(KEY_SESSION).map { s ->
        s?.split('|')?.takeIf { it.size == 5 }?.let {
            runCatching { GameSession(it[0], it[1].toLong(), it[2].toInt(), it[3].toFloat(), it[4].toInt()) }.getOrNull()
        }
    }.stateInVm(this, null)

    val reports: StateFlow<List<Report>> = history.reports(ReportType.GAME, 20).stateInVm(this, emptyList())

    private val _pre = MutableStateFlow<ScanResult?>(null)
    val preCheck: StateFlow<ScanResult?> = _pre.asStateFlow()

    init {
        viewModelScope.launch {
            apps.value = try {
                appsRepo.loadApps().filter { !it.isSystem && it.canLaunch }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { emptyList() }
            loading.value = false
        }
    }

    fun toggle(pkg: String) {
        viewModelScope.launch {
            val cur = selected.value
            val next = if (pkg in cur) cur - pkg else cur + pkg
            if (next.isEmpty()) catalog.removeSetting(KEY_GAMES) else catalog.putSetting(KEY_GAMES, next.joinToString(","))
        }
    }

    fun runPreCheck() {
        viewModelScope.launch {
            _pre.value = null
            _pre.value = try { scan(persist = false) } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
        }
    }

    fun dismissPreCheck() { _pre.value = null }

    fun startSession(pkg: String) {
        viewModelScope.launch {
            val s = system.snapshot()
            catalog.putSetting(KEY_SESSION, listOf(pkg, System.currentTimeMillis(), s.ram.usedPercent, s.battery.tempC, s.battery.levelPercent).joinToString("|"))
        }
    }

    fun endSession() {
        val sess = session.value ?: return
        viewModelScope.launch {
            val s = system.snapshot()
            val now = System.currentTimeMillis()
            history.saveReport(
                Report(
                    timestamp = now, type = ReportType.GAME,
                    healthScore = AnalysisEngine.healthScore(s),
                    ramPercent = s.ram.usedPercent, storageFreePercent = s.storage.freePercent,
                    batteryTempC = s.battery.tempC, batteryLevel = s.battery.levelPercent,
                    cpuPercent = s.cpu.usagePercent ?: -1, refPackage = sess.packageName,
                    durationMs = now - sess.startTime, ramPercentStart = sess.ramPercent, tempStartC = sess.tempC,
                ),
            )
            catalog.removeSetting(KEY_SESSION)
        }
    }

    fun cancelSession() { viewModelScope.launch { catalog.removeSetting(KEY_SESSION) } }
}

@HiltViewModel
class DeviceViewModel @Inject constructor(private val system: SystemRepository) : ViewModel() {
    val details = MutableStateFlow<DeviceDetails?>(null)
    init { viewModelScope.launch { details.value = system.deviceDetails() } }
}

@HiltViewModel
class AnalyzerViewModel @Inject constructor(private val scan: ScanSystemUseCase) : ViewModel() {
    private val _result = MutableStateFlow<ScanResult?>(null)
    val result: StateFlow<ScanResult?> = _result.asStateFlow()
    private val _busy = MutableStateFlow(true)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _busy.value = true
            _result.value = try { scan(persist = false) } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
            _busy.value = false
        }
    }
}

@HiltViewModel
class HistoryViewModel @Inject constructor(private val history: HistoryRepository) : ViewModel() {
    val scans: StateFlow<List<ScanRecord>> = history.scans(30).stateInVm(this, emptyList())
    val reports: StateFlow<List<Report>> = history.reports(null, 30).stateInVm(this, emptyList())
    fun clearAll() { viewModelScope.launch { history.clearAll() } }
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val store: SettingsStore,
    private val history: HistoryRepository,
    private val catalog: CatalogRepository,
    private val permissions: PermissionChecker,
) : ViewModel() {
    val settings: StateFlow<AppSettings> = store.settings.stateInVm(this, AppSettings())
    private val _perm = MutableStateFlow(permissions.state())
    val perm: StateFlow<PermissionState> = _perm.asStateFlow()

    fun refreshPermissions() { _perm.value = permissions.state() }
    fun setTheme(m: ThemeMode) { viewModelScope.launch { store.setTheme(m) } }
    fun setNotifications(v: Boolean) { viewModelScope.launch { store.setNotifications(v) } }
    fun setNotifyStorage(v: Boolean) { viewModelScope.launch { store.setNotifyStorage(v) } }
    fun setNotifyTemp(v: Boolean) { viewModelScope.launch { store.setNotifyTemp(v) } }
    fun setNotifyRam(v: Boolean) { viewModelScope.launch { store.setNotifyRam(v) } }
    fun setInterval(min: Int) { viewModelScope.launch { store.setInterval(min) } }
    fun setDaily(v: Boolean) { viewModelScope.launch { store.setDailyReport(v) } }
    fun setRetention(d: Int) { viewModelScope.launch { store.setRetention(d) } }

    fun resetAll() {
        viewModelScope.launch {
            history.clearAll()
            store.resetAll()
            catalog.removeSetting(KEY_GAMES)
            catalog.removeSetting(KEY_SESSION)
        }
    }
}
