package com.joyram.cleaner.domain.analysis

import android.os.PowerManager
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.model.AppStats
import com.joyram.cleaner.domain.model.Insight
import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.Severity
import com.joyram.cleaner.domain.model.SystemSnapshot

/** Local, rule based analysis engine. Works only on measured values; no network or AI service. */
object AnalysisEngine {
    const val STORAGE_WARN_FREE = 20
    const val STORAGE_CRIT_FREE = 10
    const val TEMP_WARN = 40f
    const val TEMP_CRIT = 45f
    const val RAM_WARN = 80
    const val RAM_CRIT = 90
    const val CPU_WARN = 85

    fun analyze(s: SystemSnapshot, stats: AppStats = AppStats()): List<Insight> {
        val out = mutableListOf<Insight>()
        val free = s.storage.freePercent
        when {
            free <= STORAGE_CRIT_FREE -> out += Insight(
                InsightId.STORAGE_CRITICAL, Severity.CRITICAL,
                R.string.ins_storage_crit_title, R.string.ins_storage_crit_body, R.string.ins_storage_action, listOf(free),
            )
            free < STORAGE_WARN_FREE -> out += Insight(
                InsightId.STORAGE_LOW, Severity.WARNING,
                R.string.ins_storage_low_title, R.string.ins_storage_low_body, R.string.ins_storage_action, listOf(free),
            )
        }
        val t = s.battery.tempC
        if (t >= TEMP_CRIT) {
            out += Insight(InsightId.BATTERY_HOT, Severity.CRITICAL, R.string.ins_temp_title, R.string.ins_temp_crit_body, R.string.ins_temp_action, listOf(t))
        } else if (t >= TEMP_WARN) {
            out += Insight(InsightId.BATTERY_HOT, Severity.WARNING, R.string.ins_temp_title, R.string.ins_temp_warn_body, R.string.ins_temp_action, listOf(t))
        }
        val ram = s.ram
        if (ram.lowMemory) {
            out += Insight(InsightId.LOW_MEMORY, Severity.CRITICAL, R.string.ins_lowmem_title, R.string.ins_lowmem_body, R.string.ins_ram_action)
        } else if (ram.usedPercent >= RAM_CRIT) {
            out += Insight(InsightId.RAM_HIGH, Severity.CRITICAL, R.string.ins_ram_title, R.string.ins_ram_body, R.string.ins_ram_action, listOf(ram.usedPercent))
        } else if (ram.usedPercent >= RAM_WARN) {
            out += Insight(InsightId.RAM_HIGH, Severity.WARNING, R.string.ins_ram_title, R.string.ins_ram_body, R.string.ins_ram_action, listOf(ram.usedPercent))
        }
        val cpu = s.cpu.usagePercent
        if (cpu != null && cpu >= CPU_WARN) {
            out += Insight(InsightId.CPU_HIGH, Severity.WARNING, R.string.ins_cpu_title, R.string.ins_cpu_body, R.string.ins_cpu_action, listOf(cpu))
        }
        val th = s.cpu.thermalStatus
        if (th != null && th >= PowerManager.THERMAL_STATUS_MODERATE) {
            val sev = if (th >= PowerManager.THERMAL_STATUS_SEVERE) Severity.CRITICAL else Severity.WARNING
            out += Insight(InsightId.THERMAL, sev, R.string.ins_thermal_title, R.string.ins_thermal_body, R.string.ins_temp_action)
        }
        if (stats.staleCount > 0) {
            out += Insight(InsightId.OUTDATED_APPS, Severity.INFO, R.string.ins_stale_title, R.string.ins_stale_body, R.string.ins_stale_action, listOf(stats.staleCount))
        }
        val unused = stats.unusedCount
        if (unused != null && unused > 0) {
            out += Insight(InsightId.UNUSED_APPS, Severity.INFO, R.string.ins_unused_title, R.string.ins_unused_body, R.string.ins_unused_action, listOf(unused))
        }
        if (out.isEmpty()) {
            out += Insight(InsightId.ALL_GOOD, Severity.INFO, R.string.ins_ok_title, R.string.ins_ok_body, R.string.ins_ok_action)
        }
        return out.sortedByDescending { it.severity.ordinal }
    }

    /** 0..100. Only measured values influence the score. */
    fun healthScore(s: SystemSnapshot): Int {
        var score = 100.0
        val ram = s.ram.usedPercent
        if (ram > RAM_WARN) score -= ((ram - RAM_WARN) * 1.0).coerceAtMost(20.0)
        if (s.ram.lowMemory) score -= 10
        val free = s.storage.freePercent
        if (free < STORAGE_WARN_FREE) score -= ((STORAGE_WARN_FREE - free) * 1.5).coerceAtMost(30.0)
        val temp = s.battery.tempC
        if (temp > 38f) score -= ((temp - 38f) * 3.0).coerceAtMost(25.0)
        val cpu = s.cpu.usagePercent
        if (cpu != null && cpu > 70) score -= ((cpu - 70) * 0.5).coerceAtMost(15.0)
        val th = s.cpu.thermalStatus
        if (th != null && th >= PowerManager.THERMAL_STATUS_MODERATE) score -= 10
        return score.toInt().coerceIn(0, 100)
    }
}
