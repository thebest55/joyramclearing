package com.joyram.cleaner.data.settings

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val notificationsEnabled: Boolean = true,
    val notifyStorage: Boolean = true,
    val notifyTemp: Boolean = true,
    val notifyRam: Boolean = true,
    /** 0 = automatic analysis disabled */
    val scanIntervalMinutes: Int = 0,
    val dailyReport: Boolean = false,
    val retentionDays: Int = 30,
)

private val Context.joyDataStore by preferencesDataStore(name = "joy_settings")

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val ctx: Context) {
    private object K {
        val theme = stringPreferencesKey("theme")
        val notif = booleanPreferencesKey("notif")
        val nStorage = booleanPreferencesKey("n_storage")
        val nTemp = booleanPreferencesKey("n_temp")
        val nRam = booleanPreferencesKey("n_ram")
        val interval = intPreferencesKey("interval")
        val daily = booleanPreferencesKey("daily")
        val retention = intPreferencesKey("retention")
    }

    val settings: Flow<AppSettings> = ctx.joyDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            AppSettings(
                themeMode = p[K.theme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
                notificationsEnabled = p[K.notif] ?: true,
                notifyStorage = p[K.nStorage] ?: true,
                notifyTemp = p[K.nTemp] ?: true,
                notifyRam = p[K.nRam] ?: true,
                scanIntervalMinutes = p[K.interval] ?: 0,
                dailyReport = p[K.daily] ?: false,
                retentionDays = p[K.retention] ?: 30,
            )
        }

    suspend fun setTheme(m: ThemeMode) { ctx.joyDataStore.edit { it[K.theme] = m.name } }
    suspend fun setNotifications(v: Boolean) { ctx.joyDataStore.edit { it[K.notif] = v } }
    suspend fun setNotifyStorage(v: Boolean) { ctx.joyDataStore.edit { it[K.nStorage] = v } }
    suspend fun setNotifyTemp(v: Boolean) { ctx.joyDataStore.edit { it[K.nTemp] = v } }
    suspend fun setNotifyRam(v: Boolean) { ctx.joyDataStore.edit { it[K.nRam] = v } }
    suspend fun setInterval(min: Int) { ctx.joyDataStore.edit { it[K.interval] = min } }
    suspend fun setDailyReport(v: Boolean) { ctx.joyDataStore.edit { it[K.daily] = v } }
    suspend fun setRetention(days: Int) { ctx.joyDataStore.edit { it[K.retention] = days } }
    suspend fun resetAll() { ctx.joyDataStore.edit { it.clear() } }
}
