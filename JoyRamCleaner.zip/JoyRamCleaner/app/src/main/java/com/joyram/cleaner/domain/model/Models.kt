package com.joyram.cleaner.domain.model

import android.net.Uri
import android.os.BatteryManager
import androidx.annotation.StringRes

data class TimePoint(val t: Long, val v: Float)

data class RamInfo(
    val totalBytes: Long,
    val availBytes: Long,
    val thresholdBytes: Long,
    val lowMemory: Boolean,
    val appPssBytes: Long,
) {
    val usedBytes: Long get() = (totalBytes - availBytes).coerceAtLeast(0)
    val usedPercent: Int get() = if (totalBytes > 0) ((usedBytes * 100) / totalBytes).toInt() else 0
}

enum class CpuUsageSource { PROC_STAT, FREQUENCY, UNAVAILABLE }

data class CpuInfo(
    val model: String,
    val abi: String,
    val cores: Int,
    val curFreqKhz: List<Long?>,
    val maxFreqKhz: List<Long?>,
    val usagePercent: Int?,
    val usageSource: CpuUsageSource,
    val appCpuPercent: Int,
    val thermalStatus: Int?,
    val cpuTempC: Float?,
)

data class BatteryInfo(
    val levelPercent: Int,
    val tempC: Float,
    val voltageMv: Int,
    val status: Int,
    val plugged: Int,
    val technology: String,
    val health: Int,
    val currentNowUa: Long?,
) {
    val isCharging: Boolean
        get() = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
}

data class StorageInfo(val totalBytes: Long, val freeBytes: Long) {
    val usedBytes: Long get() = (totalBytes - freeBytes).coerceAtLeast(0)
    val usedPercent: Int get() = if (totalBytes > 0) ((usedBytes * 100) / totalBytes).toInt() else 0
    val freePercent: Int get() = 100 - usedPercent
}

data class DeviceSummary(val brand: String, val model: String, val androidRelease: String, val sdk: Int)

data class SystemSnapshot(
    val timestamp: Long,
    val ram: RamInfo,
    val cpu: CpuInfo,
    val battery: BatteryInfo,
    val storage: StorageInfo,
    val device: DeviceSummary,
)

data class DeviceDetails(
    val brand: String,
    val manufacturer: String,
    val model: String,
    val product: String,
    val androidRelease: String,
    val sdk: Int,
    val securityPatch: String,
    val buildId: String,
    val fingerprint: String,
    val kernel: String,
    val abis: String,
    val cpuModel: String,
    val cpuCores: Int,
    val ramTotalBytes: Long,
    val glEsVersion: String,
    val resolution: String,
    val densityDpi: Int,
    val refreshRateHz: Float,
    val batteryTechnology: String,
    val sensors: List<String>,
    val uptimeMs: Long,
)

data class AppEntry(
    val packageName: String,
    val label: String,
    val versionName: String,
    val isSystem: Boolean,
    val installTime: Long,
    val updateTime: Long,
    val apkSizeBytes: Long,
    val lastUsed: Long?,
    val canLaunch: Boolean,
)

enum class Severity { INFO, WARNING, CRITICAL }

enum class InsightId {
    STORAGE_LOW, STORAGE_CRITICAL, BATTERY_HOT, RAM_HIGH, LOW_MEMORY, CPU_HIGH, THERMAL, OUTDATED_APPS, UNUSED_APPS, ALL_GOOD
}

data class Insight(
    val id: InsightId,
    val severity: Severity,
    @StringRes val title: Int,
    @StringRes val body: Int,
    @StringRes val action: Int,
    val args: List<Any> = emptyList(),
)

data class AppStats(val staleCount: Int = 0, val unusedCount: Int? = null)

enum class ScanStage { SNAPSHOT, APPS, ANALYZE, SAVE }

data class ScanResult(
    val snapshot: SystemSnapshot,
    val insights: List<Insight>,
    val healthScore: Int,
    val durationMs: Long,
    val appCount: Int,
    val stats: AppStats,
)

enum class ReportType { SCAN, DAILY, GAME }

data class ScanRecord(val timestamp: Long, val healthScore: Int, val issueCount: Int, val durationMs: Long)

data class Report(
    val id: Long = 0,
    val timestamp: Long,
    val type: ReportType,
    val healthScore: Int,
    val ramPercent: Int,
    val storageFreePercent: Int,
    val batteryTempC: Float,
    val batteryLevel: Int,
    val cpuPercent: Int,
    val issueIds: String = "",
    val refPackage: String? = null,
    val durationMs: Long = 0,
    val ramPercentStart: Int = 0,
    val tempStartC: Float = 0f,
)

data class GameSession(
    val packageName: String,
    val startTime: Long,
    val ramPercent: Int,
    val tempC: Float,
    val batteryLevel: Int,
)

enum class FileSource { MEDIA, TREE }
enum class FileCategory { IMAGE, VIDEO, AUDIO, DOCUMENT, ARCHIVE, APK, OTHER }

data class StoredFile(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val mime: String?,
    val modified: Long,
    val source: FileSource,
    val category: FileCategory,
    val junk: Boolean = false,
    val duplicate: Boolean = false,
) {
    val key: String get() = uri.toString()
}

data class MediaSummary(
    val imageBytes: Long = 0, val imageCount: Int = 0,
    val videoBytes: Long = 0, val videoCount: Int = 0,
    val audioBytes: Long = 0, val audioCount: Int = 0,
) {
    val totalBytes: Long get() = imageBytes + videoBytes + audioBytes
}

enum class HistoryRange(val ms: Long) {
    H1(3_600_000L), H24(86_400_000L), D7(7 * 86_400_000L)
}
