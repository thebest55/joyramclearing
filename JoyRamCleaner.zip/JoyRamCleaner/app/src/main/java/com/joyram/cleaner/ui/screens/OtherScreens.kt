package com.joyram.cleaner.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.model.HistoryRange
import com.joyram.cleaner.domain.model.ReportType
import com.joyram.cleaner.ui.components.*
import com.joyram.cleaner.ui.theme.Amber
import com.joyram.cleaner.util.Fmt

@Composable
fun DeviceScreen(onBack: () -> Unit, vm: DeviceViewModel = hiltViewModel()) {
    val d by vm.details.collectAsStateWithLifecycle()
    SubScreen(stringResource(R.string.device_title), onBack) { inner ->
        ScreenList(inner) {
            val x = d
            if (x == null) {
                item { LoadingBox() }
            } else {
                item {
                    JoyCard {
                        SectionTitle(stringResource(R.string.dev_section_device))
                        InfoRow(stringResource(R.string.dev_brand), x.brand)
                        InfoRow(stringResource(R.string.dev_manufacturer), x.manufacturer)
                        InfoRow(stringResource(R.string.dev_model), x.model)
                        InfoRow(stringResource(R.string.dev_product), x.product)
                        InfoRow(stringResource(R.string.dev_uptime), Fmt.duration(x.uptimeMs))
                    }
                }
                item {
                    JoyCard {
                        SectionTitle(stringResource(R.string.dev_section_system))
                        InfoRow(stringResource(R.string.dev_android), x.androidRelease)
                        InfoRow(stringResource(R.string.dev_api), x.sdk.toString())
                        InfoRow(stringResource(R.string.dev_patch), x.securityPatch.ifBlank { "—" })
                        InfoRow(stringResource(R.string.dev_build), x.buildId)
                        InfoRow(stringResource(R.string.dev_fingerprint), x.fingerprint)
                        InfoRow(stringResource(R.string.dev_kernel), x.kernel)
                    }
                }
                item {
                    JoyCard {
                        SectionTitle(stringResource(R.string.dev_section_hw))
                        InfoRow(stringResource(R.string.cpu_model), x.cpuModel)
                        InfoRow(stringResource(R.string.cpu_arch), x.abis)
                        InfoRow(stringResource(R.string.cpu_cores), x.cpuCores.toString())
                        InfoRow(stringResource(R.string.ram_total), Fmt.bytes(x.ramTotalBytes))
                        InfoRow(stringResource(R.string.dev_gles), x.glEsVersion.ifBlank { stringResource(R.string.not_available) })
                        NoteText(stringResource(R.string.dev_gpu_note))
                        InfoRow(stringResource(R.string.bat_tech), x.batteryTechnology.ifBlank { stringResource(R.string.unknown) })
                    }
                }
                item {
                    JoyCard {
                        SectionTitle(stringResource(R.string.dev_section_display))
                        InfoRow(stringResource(R.string.dev_resolution), x.resolution)
                        InfoRow(stringResource(R.string.dev_density), "${x.densityDpi} dpi")
                        InfoRow(stringResource(R.string.dev_refresh), "%.0f Hz".format(x.refreshRateHz))
                    }
                }
                item {
                    JoyCard {
                        SectionTitle(stringResource(R.string.dev_sensors, x.sensors.size))
                        Spacer(Modifier.height(4.dp))
                        x.sensors.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 1.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyzerScreen(onBack: () -> Unit, vm: AnalyzerViewModel = hiltViewModel()) {
    val result by vm.result.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    SubScreen(stringResource(R.string.analyzer_title), onBack, actions = {
        IconButton(onClick = vm::refresh, enabled = !busy) { Icon(Icons.Filled.Refresh, stringResource(R.string.refresh)) }
    }) { inner ->
        ScreenList(inner) {
            val r = result
            if (busy && r == null) {
                item { LoadingBox() }
            } else if (r == null) {
                item { EmptyState(Icons.Filled.Error, stringResource(R.string.scan_failed)) }
            } else {
                item {
                    JoyCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GaugeRing(r.healthScore, stringResource(R.string.health_score_label))
                            Spacer(Modifier.width(16.dp))
                            Column {
                                Text(healthLabel(r.healthScore), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                NoteText(stringResource(R.string.analyzer_apps_scanned, r.appCount))
                                NoteText(stringResource(R.string.analyzer_stale, r.stats.staleCount))
                                NoteText(r.stats.unusedCount?.let { stringResource(R.string.analyzer_unused, it) } ?: stringResource(R.string.analyzer_unused_na))
                            }
                        }
                    }
                }
                items(r.insights) { InsightCard(it) }
                item { NoteText(stringResource(R.string.analyzer_note)) }
            }
        }
    }
}

@Composable
fun HistoryScreen(onBack: () -> Unit, metrics: MetricsViewModel = hiltViewModel(), vm: HistoryViewModel = hiltViewModel()) {
    val range by metrics.selectedRange.collectAsStateWithLifecycle()
    val ram by metrics.ramSeries.collectAsStateWithLifecycle()
    val cpu by metrics.cpuSeries.collectAsStateWithLifecycle()
    val level by metrics.levelSeries.collectAsStateWithLifecycle()
    val temp by metrics.tempSeries.collectAsStateWithLifecycle()
    val storage by metrics.storageSeries.collectAsStateWithLifecycle()
    val scans by vm.scans.collectAsStateWithLifecycle()
    val reports by vm.reports.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }

    SubScreen(stringResource(R.string.history_title), onBack) { inner ->
        ScreenList(inner) {
            item { ChipRow(HistoryRange.entries, range, { rangeLabel(it) }, metrics::setRange) }
            item { JoyCard { SectionTitle(stringResource(R.string.hist_ram)); LineChart(ram, minY = 0f, maxY = 100f, unit = "%") } }
            item { JoyCard { SectionTitle(stringResource(R.string.hist_cpu)); LineChart(cpu, minY = 0f, maxY = 100f, unit = "%") } }
            item { JoyCard { SectionTitle(stringResource(R.string.hist_battery)); LineChart(level, minY = 0f, maxY = 100f, unit = "%") } }
            item { JoyCard { SectionTitle(stringResource(R.string.bat_temp_history)); LineChart(temp, color = Amber, unit = "°") } }
            item { JoyCard { SectionTitle(stringResource(R.string.hist_storage)); LineChart(storage, minY = 0f, maxY = 100f, unit = "%") } }
            item { SectionTitle(stringResource(R.string.hist_scans)) }
            if (scans.isEmpty()) {
                item { NoteText(stringResource(R.string.hist_empty)) }
            } else {
                items(scans) { s ->
                    JoyCard {
                        Text(Fmt.dateTime(s.timestamp), fontWeight = FontWeight.SemiBold)
                        NoteText(stringResource(R.string.hist_scan_row, s.healthScore, s.issueCount, s.durationMs))
                    }
                }
            }
            item { SectionTitle(stringResource(R.string.hist_reports)) }
            val nonGame = reports.filter { it.type != ReportType.GAME }
            if (nonGame.isEmpty()) {
                item { NoteText(stringResource(R.string.hist_empty)) }
            } else {
                items(nonGame, key = { it.id }) { r ->
                    JoyCard {
                        Text(
                            stringResource(if (r.type == ReportType.DAILY) R.string.report_daily else R.string.report_scan) + " · " + Fmt.dateTime(r.timestamp),
                            fontWeight = FontWeight.SemiBold,
                        )
                        NoteText(stringResource(R.string.hist_report_row, r.healthScore, r.ramPercent, r.storageFreePercent, Fmt.temp(r.batteryTempC)))
                    }
                }
            }
            item {
                OutlinedButton(
                    onClick = { confirm = true }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) {
                    Icon(Icons.Filled.Delete, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.hist_delete_all))
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.hist_delete_all)) },
            text = { Text(stringResource(R.string.hist_delete_confirm)) },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirm = false }) { Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    SubScreen(stringResource(R.string.privacy_title), onBack) { inner ->
        ScreenList(inner) {
            listOf(
                R.string.privacy_1_t to R.string.privacy_1_b,
                R.string.privacy_2_t to R.string.privacy_2_b,
                R.string.privacy_3_t to R.string.privacy_3_b,
                R.string.privacy_4_t to R.string.privacy_4_b,
                R.string.privacy_5_t to R.string.privacy_5_b,
                R.string.privacy_6_t to R.string.privacy_6_b,
            ).forEach { (t, b) ->
                item {
                    JoyCard {
                        Text(stringResource(t), fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(stringResource(b))
                    }
                }
            }
        }
    }
}
