package com.joyram.cleaner.util

import java.text.DateFormat
import java.util.Date
import java.util.Locale

object Fmt {
    fun bytes(b: Long): String {
        if (b <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = 0
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return if (i == 0) "$b B" else String.format(Locale.getDefault(), "%.1f %s", v, units[i])
    }

    fun dateTime(ms: Long): String =
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ms))

    fun date(ms: Long): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

    fun mhz(khz: Long?): String = if (khz == null) "—" else "${khz / 1000} MHz"

    fun temp(c: Float): String = String.format(Locale.getDefault(), "%.1f °C", c)

    /** "3d 4h 12m" style duration. */
    fun duration(ms: Long): String {
        val totalMin = ms / 60_000
        val d = totalMin / 1440
        val h = (totalMin % 1440) / 60
        val m = totalMin % 60
        return buildString {
            if (d > 0) append("${d}d ")
            if (d > 0 || h > 0) append("${h}h ")
            append("${m}m")
        }
    }
}
