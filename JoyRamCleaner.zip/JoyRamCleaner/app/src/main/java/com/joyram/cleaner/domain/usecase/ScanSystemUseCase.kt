package com.joyram.cleaner.domain.usecase

import com.joyram.cleaner.domain.analysis.AnalysisEngine
import com.joyram.cleaner.domain.model.*
import com.joyram.cleaner.domain.repository.*
import kotlinx.coroutines.CancellationException
import javax.inject.Inject

class ScanSystemUseCase @Inject constructor(
    private val system: SystemRepository,
    private val apps: AppsRepository,
    private val history: HistoryRepository,
    private val catalog: CatalogRepository,
) {
    suspend operator fun invoke(
        persist: Boolean,
        type: ReportType = ReportType.SCAN,
        onStage: (ScanStage) -> Unit = {},
    ): ScanResult {
        val started = System.currentTimeMillis()
        onStage(ScanStage.SNAPSHOT)
        val snap = system.snapshot()

        onStage(ScanStage.APPS)
        val appList = try {
            apps.loadApps()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val userApps = appList.filter { !it.isSystem }
        val stale = userApps.count { now - it.updateTime > 365 * day }
        val unused = if (apps.hasUsageAccess()) {
            userApps.count { app ->
                now - app.installTime > 30 * day && (app.lastUsed == null || now - app.lastUsed > 30 * day)
            }
        } else null
        val stats = AppStats(stale, unused)

        onStage(ScanStage.ANALYZE)
        val insights = AnalysisEngine.analyze(snap, stats)
        val score = AnalysisEngine.healthScore(snap)
        val duration = System.currentTimeMillis() - started
        val result = ScanResult(snap, insights, score, duration, appList.size, stats)

        if (persist) {
            onStage(ScanStage.SAVE)
            val issues = insights.filter { it.id != InsightId.ALL_GOOD }
            history.record(snap, force = true)
            catalog.saveDevice(snap.device, System.getProperty("os.version").orEmpty())
            history.saveScan(ScanRecord(now, score, issues.size, duration))
            history.saveReport(
                Report(
                    timestamp = now, type = type, healthScore = score,
                    ramPercent = snap.ram.usedPercent, storageFreePercent = snap.storage.freePercent,
                    batteryTempC = snap.battery.tempC, batteryLevel = snap.battery.levelPercent,
                    cpuPercent = snap.cpu.usagePercent ?: -1,
                    issueIds = issues.joinToString(",") { it.id.name },
                ),
            )
        }
        return result
    }
}
