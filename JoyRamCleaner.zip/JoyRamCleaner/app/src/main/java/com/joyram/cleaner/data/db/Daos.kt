package com.joyram.cleaner.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Insert suspend fun insertRam(e: RamHistoryEntity)
    @Insert suspend fun insertCpu(e: CpuHistoryEntity)
    @Insert suspend fun insertBattery(e: BatteryHistoryEntity)
    @Insert suspend fun insertStorage(e: StorageHistoryEntity)
    @Insert suspend fun insertScan(e: ScanHistoryEntity)
    @Insert suspend fun insertReport(e: PerformanceReportEntity)

    @Query("SELECT * FROM RamHistory WHERE timestamp >= :since ORDER BY timestamp ASC")
    fun ram(since: Long): Flow<List<RamHistoryEntity>>

    @Query("SELECT * FROM CpuHistory WHERE timestamp >= :since ORDER BY timestamp ASC")
    fun cpu(since: Long): Flow<List<CpuHistoryEntity>>

    @Query("SELECT * FROM BatteryHistory WHERE timestamp >= :since ORDER BY timestamp ASC")
    fun battery(since: Long): Flow<List<BatteryHistoryEntity>>

    @Query("SELECT * FROM StorageHistory WHERE timestamp >= :since ORDER BY timestamp ASC")
    fun storage(since: Long): Flow<List<StorageHistoryEntity>>

    @Query("SELECT * FROM ScanHistory ORDER BY timestamp DESC LIMIT 1")
    fun latestScan(): Flow<ScanHistoryEntity?>

    @Query("SELECT * FROM ScanHistory ORDER BY timestamp DESC LIMIT :limit")
    fun scans(limit: Int): Flow<List<ScanHistoryEntity>>

    @Query("SELECT * FROM PerformanceReport ORDER BY timestamp DESC LIMIT :limit")
    fun allReports(limit: Int): Flow<List<PerformanceReportEntity>>

    @Query("SELECT * FROM PerformanceReport WHERE type = :type ORDER BY timestamp DESC LIMIT :limit")
    fun reportsOfType(type: String, limit: Int): Flow<List<PerformanceReportEntity>>

    @Query("DELETE FROM RamHistory WHERE timestamp < :before") suspend fun pruneRam(before: Long)
    @Query("DELETE FROM CpuHistory WHERE timestamp < :before") suspend fun pruneCpu(before: Long)
    @Query("DELETE FROM BatteryHistory WHERE timestamp < :before") suspend fun pruneBattery(before: Long)
    @Query("DELETE FROM StorageHistory WHERE timestamp < :before") suspend fun pruneStorage(before: Long)
    @Query("DELETE FROM ScanHistory WHERE timestamp < :before") suspend fun pruneScans(before: Long)
    @Query("DELETE FROM PerformanceReport WHERE timestamp < :before") suspend fun pruneReports(before: Long)

    @Transaction
    suspend fun pruneAll(before: Long) {
        pruneRam(before); pruneCpu(before); pruneBattery(before)
        pruneStorage(before); pruneScans(before); pruneReports(before)
    }

    @Transaction
    suspend fun recordAll(ram: RamHistoryEntity, cpu: CpuHistoryEntity, bat: BatteryHistoryEntity, sto: StorageHistoryEntity) {
        insertRam(ram); insertCpu(cpu); insertBattery(bat); insertStorage(sto)
    }
}

@Dao
abstract class CatalogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun upsertApps(list: List<AppInfoEntity>)
    @Query("DELETE FROM AppInfo") abstract suspend fun deleteApps()
    @Query("SELECT * FROM AppInfo ORDER BY label COLLATE NOCASE") abstract suspend fun apps(): List<AppInfoEntity>

    @Transaction
    open suspend fun replaceApps(list: List<AppInfoEntity>) {
        deleteApps()
        upsertApps(list)
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun upsertDevice(e: DeviceInfoEntity)
    @Query("SELECT * FROM DeviceInfo WHERE id = 1") abstract suspend fun device(): DeviceInfoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun putSetting(e: UserSettingEntity)
    @Query("SELECT value FROM UserSettings WHERE name = :name") abstract suspend fun getSetting(name: String): String?
    @Query("SELECT value FROM UserSettings WHERE name = :name") abstract fun observeSetting(name: String): Flow<String?>
    @Query("DELETE FROM UserSettings WHERE name = :name") abstract suspend fun removeSetting(name: String)
}
