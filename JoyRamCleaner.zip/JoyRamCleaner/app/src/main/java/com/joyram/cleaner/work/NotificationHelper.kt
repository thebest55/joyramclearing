package com.joyram.cleaner.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.joyram.cleaner.MainActivity
import com.joyram.cleaner.R
import com.joyram.cleaner.data.settings.AppSettings
import com.joyram.cleaner.domain.model.Insight
import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.Severity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(@ApplicationContext private val ctx: Context) {
    companion object {
        const val CH_ALERTS = "alerts"
        const val CH_REPORTS = "reports"
    }

    fun createChannels() {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, ctx.getString(R.string.ch_alerts), NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_REPORTS, ctx.getString(R.string.ch_reports), NotificationManager.IMPORTANCE_LOW))
    }

    private fun canPost(): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    private fun contentIntent(): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun post(id: Int, channel: String, title: String, text: String) {
        if (!canPost()) return
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(contentIntent())
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (_: SecurityException) { }
    }

    /** Posts alerts for storage, temperature and RAM insights according to the user's settings. */
    fun notifyInsights(insights: List<Insight>, s: AppSettings) {
        if (!s.notificationsEnabled) return
        insights.filter { it.severity != Severity.INFO }.forEach { i ->
            val enabled = when (i.id) {
                InsightId.STORAGE_LOW, InsightId.STORAGE_CRITICAL -> s.notifyStorage
                InsightId.BATTERY_HOT, InsightId.THERMAL -> s.notifyTemp
                InsightId.RAM_HIGH, InsightId.LOW_MEMORY -> s.notifyRam
                else -> false
            }
            if (enabled) post(i.id.ordinal + 100, CH_ALERTS, ctx.getString(i.title), ctx.getString(i.body, *i.args.toTypedArray()))
        }
    }

    fun notifyDailyReport(score: Int, ramPct: Int, freePct: Int, tempC: Float) {
        val text = ctx.getString(R.string.daily_report_text, score, ramPct, freePct, tempC)
        post(900, CH_REPORTS, ctx.getString(R.string.daily_report_title), text)
    }
}
