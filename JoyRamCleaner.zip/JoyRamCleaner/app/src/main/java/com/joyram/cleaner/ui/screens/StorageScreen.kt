package com.joyram.cleaner.ui.screens

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.model.FileCategory
import com.joyram.cleaner.domain.model.FileSource
import com.joyram.cleaner.domain.model.StoredFile
import com.joyram.cleaner.ui.components.*
import com.joyram.cleaner.ui.theme.Amber
import com.joyram.cleaner.ui.theme.Blue
import com.joyram.cleaner.ui.theme.Cyan
import com.joyram.cleaner.util.Fmt
import com.joyram.cleaner.util.MediaPermissions

private fun hasMediaPermission(ctx: android.content.Context) = MediaPermissions.required().all {
    ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun categoryLabel(c: FileCategory): String = stringResource(
    when (c) {
        FileCategory.IMAGE -> R.string.cat_images
        FileCategory.VIDEO -> R.string.cat_videos
        FileCategory.AUDIO -> R.string.cat_audio
        FileCategory.DOCUMENT -> R.string.cat_documents
        FileCategory.ARCHIVE -> R.string.cat_archives
        FileCategory.APK -> R.string.cat_apk
        FileCategory.OTHER -> R.string.cat_other
    },
)

@Composable
fun StorageScreen(vm: StorageViewModel = hiltViewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var hasMedia by remember { mutableStateOf(hasMediaPermission(ctx)) }
    var pendingMediaCount by remember { mutableIntStateOf(0) }
    var confirmDelete by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        hasMedia = res.values.all { it }
        if (hasMedia) vm.loadMedia()
    }
    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            } catch (_: Exception) { }
            vm.scanFolder(uri)
        }
    }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) vm.onMediaDeleted(pendingMediaCount)
    }
    LaunchedEffect(hasMedia) { if (hasMedia) vm.loadMedia() }

    val canDeleteMedia = Build.VERSION.SDK_INT >= 30
    val files = remember(ui.mediaFiles, ui.treeFiles, ui.sort, ui.filter) {
        val base = (ui.mediaFiles + ui.treeFiles).filter {
            when (ui.filter) {
                FileFilter.ALL -> true
                FileFilter.JUNK -> it.junk
                FileFilter.DUPLICATES -> it.duplicate
            }
        }
        when (ui.sort) {
            FileSort.SIZE -> base.sortedByDescending { it.sizeBytes }
            FileSort.NAME -> base.sortedBy { it.name.lowercase() }
            FileSort.DATE -> base.sortedByDescending { it.modified }
        }
    }
    val selectedFiles = (ui.mediaFiles + ui.treeFiles).filter { it.key in ui.selected }
    val junkAll = (ui.mediaFiles + ui.treeFiles).filter { it.junk || it.duplicate }

    ScreenList {
        item { TabHeader(stringResource(R.string.storage_title)) }
        item {
            val st = ui.storage
            JoyCard {
                if (st == null) {
                    LoadingBox()
                } else {
                    InfoRow(stringResource(R.string.storage_total), Fmt.bytes(st.totalBytes))
                    InfoRow(stringResource(R.string.storage_used), Fmt.bytes(st.usedBytes))
                    InfoRow(stringResource(R.string.storage_free), Fmt.bytes(st.freeBytes))
                    Spacer(Modifier.height(10.dp))
                    val m = ui.media
                    val total = st.totalBytes.toFloat().coerceAtLeast(1f)
                    val img = (m?.imageBytes ?: 0L) / total
                    val vid = (m?.videoBytes ?: 0L) / total
                    val aud = (m?.audioBytes ?: 0L) / total
                    val other = (st.usedBytes / total - img - vid - aud).coerceAtLeast(0f)
                    SegmentedBar(listOf(Segment(img, Blue), Segment(vid, Cyan), Segment(aud, Amber), Segment(other, MaterialTheme.colorScheme.outline)))
                    Spacer(Modifier.height(8.dp))
                    if (m != null) {
                        InfoRow(stringResource(R.string.cat_images), "${Fmt.bytes(m.imageBytes)} (${m.imageCount})")
                        InfoRow(stringResource(R.string.cat_videos), "${Fmt.bytes(m.videoBytes)} (${m.videoCount})")
                        InfoRow(stringResource(R.string.cat_audio), "${Fmt.bytes(m.audioBytes)} (${m.audioCount})")
                    }
                    InfoRow(stringResource(R.string.storage_free_pct), "${st.freePercent}%")
                }
            }
        }
        if (!hasMedia) {
            item {
                JoyCard {
                    Text(stringResource(R.string.storage_perm_why))
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { permLauncher.launch(MediaPermissions.required()) }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.grant_access))
                    }
                }
            }
        }
        item {
            JoyCard {
                Text(stringResource(R.string.storage_folder_title), fontWeight = FontWeight.SemiBold)
                NoteText(stringResource(R.string.storage_folder_note))
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { treeLauncher.launch(null) }, enabled = !ui.scanning, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Folder, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.storage_scan_folder))
                }
                if (ui.scanning) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
        }
        if (junkAll.isNotEmpty()) {
            item {
                JoyCard {
                    Text(stringResource(R.string.storage_junk_title), fontWeight = FontWeight.SemiBold)
                    Text(stringResource(R.string.storage_junk_body, junkAll.size, Fmt.bytes(junkAll.sumOf { it.sizeBytes })))
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = { vm.setFilter(FileFilter.JUNK) }) { Text(stringResource(R.string.show_junk)) }
                }
            }
        }
        ui.deleted?.let { n ->
            item {
                JoyCard {
                    Text(stringResource(R.string.storage_deleted, n))
                    TextButton(onClick = vm::dismissDeleted) { Text(stringResource(R.string.ok)) }
                }
            }
        }
        item { SectionTitle(stringResource(R.string.storage_files)) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipRow(FileSort.entries, ui.sort, { stringResource(sortLabel(it)) }, vm::setSort)
                ChipRow(FileFilter.entries, ui.filter, { stringResource(filterLabel(it)) }, vm::setFilter)
                if (!canDeleteMedia) NoteText(stringResource(R.string.storage_media_delete_note))
            }
        }
        if (files.isEmpty()) {
            item { EmptyState(Icons.Filled.FolderOpen, stringResource(R.string.storage_no_files)) }
        } else {
            items(files, key = { it.key }) { f ->
                FileRow(f, f.key in ui.selected, canDeleteMedia || f.source == FileSource.TREE) { vm.toggle(f) }
            }
        }
        if (selectedFiles.isNotEmpty()) {
            item {
                Button(
                    onClick = { confirmDelete = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.Delete, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.delete_selected, selectedFiles.size, Fmt.bytes(selectedFiles.sumOf { it.sizeBytes })))
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.confirm_delete_title)) },
            text = { Text(stringResource(R.string.confirm_delete_body, selectedFiles.size)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val tree = selectedFiles.filter { it.source == FileSource.TREE }
                    val media = selectedFiles.filter { it.source == FileSource.MEDIA }
                    if (tree.isNotEmpty()) vm.deleteTreeFiles(tree)
                    if (media.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
                        pendingMediaCount = media.size
                        val pi = MediaStore.createDeleteRequest(ctx.contentResolver, media.map { it.uri })
                        deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                    }
                }) { Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

private fun sortLabel(s: FileSort) = when (s) {
    FileSort.SIZE -> R.string.sort_size
    FileSort.NAME -> R.string.sort_name
    FileSort.DATE -> R.string.sort_date
}

private fun filterLabel(f: FileFilter) = when (f) {
    FileFilter.ALL -> R.string.filter_all
    FileFilter.JUNK -> R.string.filter_junk
    FileFilter.DUPLICATES -> R.string.filter_duplicates
}

@Composable
private fun FileRow(f: StoredFile, selected: Boolean, enabled: Boolean, onToggle: () -> Unit) {
    JoyCard(onClick = if (enabled) onToggle else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = selected, onCheckedChange = { onToggle() }, enabled = enabled)
            Column(Modifier.weight(1f)) {
                Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                NoteText(buildString {
                    append(Fmt.bytes(f.sizeBytes))
                    if (f.modified > 0) append(" · ").append(Fmt.date(f.modified))
                })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NoteText(categoryLabel(f.category))
                    if (f.junk) Text(stringResource(R.string.tag_junk), style = MaterialTheme.typography.labelSmall, color = Amber)
                    if (f.duplicate) Text(stringResource(R.string.tag_duplicate), style = MaterialTheme.typography.labelSmall, color = Amber)
                }
            }
        }
    }
}
