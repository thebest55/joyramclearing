package com.joyram.cleaner.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.analysis.AnalysisEngine
import com.joyram.cleaner.domain.model.HistoryRange
import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.TimePoint
import com.joyram.cleaner.ui.components.*
import com.joyram.cleaner.ui.theme.Amber
import com.joyram.cleaner.util.Fmt
import java.util.Locale

@Composable
fun RamScreen(vm: MetricsViewModel = hiltViewModel()) {
    val live by vm.live.collectAsStateWithLifecycle()
    val range by vm.selectedRange.collectAsStateWithLifecycle()
    val series by vm.ramSeries.collectAsStateWithLifecycle()
    val cache by vm.cacheBytes.collectAsStateWithLifecycle()
    val freed by vm.freedBytes.collectAsStateWithLifecycle()
    val snap = live.lastOrNull()
    val ram = snap?.ram

    ScreenList {
        item { TabHeader(stringResource(R.string.ram_title)) }
        if (snap == null || ram == null) {
            item { LoadingBox() }
        } else {
            item {
                JoyCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GaugeRing(ram.usedPercent, "%")
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            InfoRow(stringResource(R.string.ram_total), Fmt.bytes(ram.totalBytes))
                            InfoRow(stringResource(R.string.ram_used), Fmt.bytes(ram.usedBytes))
                            InfoRow(stringResource(R.string.ram_available), Fmt.bytes(ram.availBytes))
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    InfoRow(stringResource(R.string.ram_threshold), Fmt.bytes(ram.thresholdBytes))
                    val pressure = when {
                        ram.lowMemory -> R.string.ram_pressure_critical
                        ram.usedPercent >= AnalysisEngine.RAM_WARN -> R.string.ram_pressure_high
                        else -> R.string.ram_pressure_normal
                    }
                    InfoRow(stringResource(R.string.ram_pressure), stringResource(pressure))
                }
            }
            item {
                JoyCard {
                    SectionTitle(stringResource(R.string.live_chart))
                    Spacer(Modifier.height(8.dp))
                    LineChart(live.map { TimePoint(it.timestamp, it.ram.usedPercent.toFloat()) }, minY = 0f, maxY = 100f, unit = "%")
                }
            }
            item { HistoryCard(stringResource(R.string.history_chart), range, vm::setRange, series, "%", 0f, 100f) }
            item {
                JoyCard {
                    SectionTitle(stringResource(R.string.ram_app_memory))
                    InfoRow(stringResource(R.string.ram_app_pss), Fmt.bytes(ram.appPssBytes))
                    Spacer(Modifier.height(4.dp))
                    NoteText(stringResource(R.string.ram_other_apps_note))
                }
            }
            val ramInsights = AnalysisEngine.analyze(snap).filter { it.id == InsightId.RAM_HIGH || it.id == InsightId.LOW_MEMORY }
            item { SectionTitle(stringResource(R.string.ram_report)) }
            if (ramInsights.isEmpty()) {
                item { JoyCard { Text(stringResource(R.string.ram_report_ok)) } }
            } else {
                items(ramInsights) { InsightCard(it) }
            }
            item {
                JoyCard {
                    SectionTitle(stringResource(R.string.ram_optimize))
                    Spacer(Modifier.height(6.dp))
                    listOf(R.string.ram_tip_1, R.string.ram_tip_2, R.string.ram_tip_3).forEach {
                        Text("• " + stringResource(it), Modifier.padding(vertical = 2.dp))
                    }
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    InfoRow(stringResource(R.string.ram_own_cache), Fmt.bytes(cache))
                    NoteText(stringResource(R.string.ram_clean_note))
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = vm::clearCache, enabled = cache > 0, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.DeleteSweep, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.ram_clear_cache))
                    }
                }
            }
        }
    }
    freed?.let {
        AlertDialog(
            onDismissRequest = vm::dismissFreed,
            title = { Text(stringResource(R.string.ram_clear_cache)) },
            text = { Text(stringResource(R.string.ram_freed_result, Fmt.bytes(it))) },
            confirmButton = { TextButton(onClick = vm::dismissFreed) { Text(stringResource(R.string.ok)) } },
        )
    }
}

@Composable
fun HistoryCard(
    title: String,
    range: HistoryRange,
    onRange: (HistoryRange) -> Unit,
    series: List<TimePoint>,
    unit: String,
    minY: Float? = null,
    maxY: Float? = null,
) {
    JoyCard {
        SectionTitle(title)
        Spacer(Modifier.height(8.dp))
        ChipRow(HistoryRange.entries, range, { rangeLabel(it) }, onRange)
        Spacer(Modifier.height(8.dp))
        LineChart(series, minY = minY, maxY = maxY, unit = unit)
    }
}

@Composable
fun CpuScreen(onBack: () -> Unit, vm: MetricsViewModel = hiltViewModel()) {
    val live by vm.live.collectAsStateWithLifecycle()
    val range by vm.selectedRange.collectAsStateWithLifecycle()
    val series by vm.cpuSeries.collectAsStateWithLifecycle()
    val snap = live.lastOrNull()
    SubScreen(stringResource(R.string.cpu_title), onBack) { inner ->
        ScreenList(inner) {
            if (snap == null) {
                item { LoadingBox() }
            } else {
                val cpu = snap.cpu
                item {
                    JoyCard {
                        InfoRow(stringResource(R.string.cpu_model), cpu.model)
                        InfoRow(stringResource(R.string.cpu_arch), cpu.abi)
                        InfoRow(stringResource(R.string.cpu_cores), cpu.cores.toString())
                        InfoRow(stringResource(R.string.cpu_usage), cpu.usagePercent?.let { "$it%" } ?: stringResource(R.string.not_supported))
                        InfoRow(stringResource(R.string.cpu_usage_source), cpuSourceText(cpu.usageSource))
                        InfoRow(stringResource(R.string.cpu_app_usage), "${cpu.appCpuPercent}%")
                        InfoRow(stringResource(R.string.cpu_thermal), thermalText(cpu.thermalStatus))
                        InfoRow(stringResource(R.string.cpu_temp), cpu.cpuTempC?.let { Fmt.temp(it) } ?: stringResource(R.string.not_supported))
                    }
                }
                val high = AnalysisEngine.analyze(snap).filter { it.id == InsightId.CPU_HIGH || it.id == InsightId.THERMAL }
                items(high) { InsightCard(it) }
                item {
                    JoyCard {
                        SectionTitle(stringResource(R.string.cpu_freqs))
                        Spacer(Modifier.height(6.dp))
                        if (cpu.curFreqKhz.all { it == null }) {
                            NoteText(stringResource(R.string.cpu_freq_unsupported))
                        } else {
                            cpu.curFreqKhz.forEachIndexed { i, cur ->
                                val max = cpu.maxFreqKhz.getOrNull(i)
                                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("#$i", Modifier.width(32.dp), style = MaterialTheme.typography.labelMedium)
                                    StatBar(if (cur != null && max != null && max > 0) (cur * 100 / max).toInt() else 0, Modifier.weight(1f))
                                    Text(Fmt.mhz(cur), Modifier.width(84.dp), style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
                item {
                    JoyCard {
                        SectionTitle(stringResource(R.string.live_chart))
                        Spacer(Modifier.height(8.dp))
                        val pts = live.mapNotNull { s -> s.cpu.usagePercent?.let { TimePoint(s.timestamp, it.toFloat()) } }
                        LineChart(pts, minY = 0f, maxY = 100f, unit = "%")
                        if (cpu.usagePercent == null) NoteText(stringResource(R.string.cpu_usage_unsupported_note))
                    }
                }
                item { HistoryCard(stringResource(R.string.history_chart), range, vm::setRange, series, "%", 0f, 100f) }
            }
        }
    }
}

@Composable
fun BatteryScreen(vm: MetricsViewModel = hiltViewModel()) {
    val live by vm.live.collectAsStateWithLifecycle()
    val range by vm.selectedRange.collectAsStateWithLifecycle()
    val levels by vm.levelSeries.collectAsStateWithLifecycle()
    val temps by vm.tempSeries.collectAsStateWithLifecycle()
    val snap = live.lastOrNull()
    ScreenList {
        item { TabHeader(stringResource(R.string.battery_title)) }
        if (snap == null) {
            item { LoadingBox() }
        } else {
            val b = snap.battery
            item {
                JoyCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GaugeRing(b.levelPercent, "%")
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            InfoRow(stringResource(R.string.bat_status), batteryStatusText(b.status))
                            InfoRow(stringResource(R.string.bat_source), pluggedText(b.plugged))
                            InfoRow(stringResource(R.string.bat_temp), Fmt.temp(b.tempC))
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    InfoRow(stringResource(R.string.bat_voltage), "${b.voltageMv} mV")
                    InfoRow(stringResource(R.string.bat_tech), b.technology.ifBlank { stringResource(R.string.unknown) })
                    InfoRow(stringResource(R.string.bat_health), batteryHealthText(b.health))
                    InfoRow(
                        stringResource(R.string.bat_current),
                        b.currentNowUa?.let { "${it / 1000} mA" } ?: stringResource(R.string.not_supported),
                    )
                    NoteText(stringResource(R.string.bat_health_note))
                }
            }
            items(AnalysisEngine.analyze(snap).filter { it.id == InsightId.BATTERY_HOT }) { InsightCard(it) }
            item {
                JoyCard {
                    SectionTitle(stringResource(R.string.bat_history))
                    Spacer(Modifier.height(8.dp))
                    ChipRow(HistoryRange.entries, range, { rangeLabel(it) }, vm::setRange)
                    Spacer(Modifier.height(8.dp))
                    NoteText(stringResource(R.string.bat_level_chart))
                    LineChart(levels, minY = 0f, maxY = 100f, unit = "%")
                    val rate = chargeRatePerHour(levels)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (rate == null) stringResource(R.string.bat_rate_unknown)
                        else stringResource(R.string.bat_rate, String.format(Locale.getDefault(), "%+.1f", rate)),
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
            item {
                JoyCard {
                    SectionTitle(stringResource(R.string.bat_temp_history))
                    Spacer(Modifier.height(8.dp))
                    LineChart(temps, color = Amber, unit = "°")
                }
            }
        }
    }
}

/** Percent per hour between first and last sample; null when there is not enough data (< 10 minutes). */
fun chargeRatePerHour(points: List<TimePoint>): Float? {
    if (points.size < 2) return null
    val span = points.last().t - points.first().t
    if (span < 10 * 60_000L) return null
    return (points.last().v - points.first().v) / (span / 3_600_000f)
}
