package com.joyram.cleaner.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.joyram.cleaner.domain.repository.AppsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

object MediaPermissions {
    fun required(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
}

data class PermissionState(val notifications: Boolean, val media: Boolean, val usageAccess: Boolean)

@Singleton
class PermissionChecker @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val apps: AppsRepository,
) {
    fun mediaGranted(): Boolean = MediaPermissions.required().all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    fun notificationsGranted(): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun state() = PermissionState(notificationsGranted(), mediaGranted(), apps.hasUsageAccess())
}
