package com.joyram.cleaner.ui.nav

object Routes {
    const val HOME = "home"
    const val RAM = "ram"
    const val STORAGE = "storage"
    const val BATTERY = "battery"
    const val SETTINGS = "settings"
    const val CPU = "cpu"
    const val APPS = "apps"
    const val GAME = "game"
    const val DEVICE = "device"
    const val ANALYZER = "analyzer"
    const val HISTORY = "history"
    const val PRIVACY = "privacy"
}
