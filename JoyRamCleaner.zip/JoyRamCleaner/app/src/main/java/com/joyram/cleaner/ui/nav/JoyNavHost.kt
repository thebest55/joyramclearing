package com.joyram.cleaner.ui.nav

import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.joyram.cleaner.R
import com.joyram.cleaner.ui.screens.*

private data class Tab(val route: String, val icon: ImageVector, val label: Int)

@Composable
fun JoyNavHost() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val tabs = listOf(
        Tab(Routes.HOME, Icons.Filled.Home, R.string.nav_home),
        Tab(Routes.RAM, Icons.Filled.Memory, R.string.nav_ram),
        Tab(Routes.STORAGE, Icons.Filled.Storage, R.string.nav_storage),
        Tab(Routes.BATTERY, Icons.Filled.BatteryFull, R.string.nav_battery),
        Tab(Routes.SETTINGS, Icons.Filled.Settings, R.string.nav_settings),
    )
    val tabRoutes = tabs.map { it.route }

    fun go(route: String) {
        if (route in tabRoutes) {
            nav.navigate(route) {
                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        } else {
            nav.navigate(route) { launchSingleTop = true }
        }
    }
    val back: () -> Unit = { nav.popBackStack() }

    Scaffold(
        bottomBar = {
            if (current in tabRoutes) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = current == t.route,
                            onClick = { go(t.route) },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(stringResource(t.label)) },
                        )
                    }
                }
            }
        },
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(inner).consumeWindowInsets(inner),
        ) {
            composable(Routes.HOME) { HomeScreen(onNavigate = ::go) }
            composable(Routes.RAM) { RamScreen() }
            composable(Routes.STORAGE) { StorageScreen() }
            composable(Routes.BATTERY) { BatteryScreen() }
            composable(Routes.SETTINGS) { SettingsScreen(onNavigate = ::go) }
            composable(Routes.CPU) { CpuScreen(onBack = back) }
            composable(Routes.APPS) { AppsScreen(onBack = back) }
            composable(Routes.GAME) { GameScreen(onBack = back) }
            composable(Routes.DEVICE) { DeviceScreen(onBack = back) }
            composable(Routes.ANALYZER) { AnalyzerScreen(onBack = back) }
            composable(Routes.HISTORY) { HistoryScreen(onBack = back) }
            composable(Routes.PRIVACY) { PrivacyScreen(onBack = back) }
        }
    }
}
