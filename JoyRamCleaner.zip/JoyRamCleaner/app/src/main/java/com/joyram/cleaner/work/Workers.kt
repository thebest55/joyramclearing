package com.joyram.cleaner.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.joyram.cleaner.data.settings.SettingsStore
import com.joyram.cleaner.domain.model.ReportType
import com.joyram.cleaner.domain.usecase.ScanSystemUseCase
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@HiltWorker
class AnalysisWorker @AssistedInject constructor(
    @Assisted ctx: Context,
    @Assisted params: WorkerParameters,
    private val scan: ScanSystemUseCase,
    private val settings: SettingsStore,
    private val notifier: NotificationHelper,
) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        val result = scan(persist = true, type = ReportType.SCAN)
        notifier.notifyInsights(result.insights, settings.settings.first())
        Result.success()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}

@HiltWorker
class DailyReportWorker @AssistedInject constructor(
    @Assisted ctx: Context,
    @Assisted params: WorkerParameters,
    private val scan: ScanSystemUseCase,
    private val settings: SettingsStore,
    private val notifier: NotificationHelper,
) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        val r = scan(persist = true, type = ReportType.DAILY)
        if (settings.settings.first().notificationsEnabled) {
            notifier.notifyDailyReport(r.healthScore, r.snapshot.ram.usedPercent, r.snapshot.storage.freePercent, r.snapshot.battery.tempC)
        }
        Result.success()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}

/**
 * Background work is periodic and subject to Android's battery limits (minimum 15 minutes,
 * may be deferred by Doze). It is NOT continuous real-time monitoring.
 */
@Singleton
class WorkScheduler @Inject constructor(@ApplicationContext private val context: Context) {
    private val wm get() = WorkManager.getInstance(context)

    fun apply(intervalMinutes: Int, dailyReport: Boolean) {
        if (intervalMinutes >= 15) {
            val req = PeriodicWorkRequestBuilder<AnalysisWorker>(intervalMinutes.toLong(), TimeUnit.MINUTES).build()
            wm.enqueueUniquePeriodicWork("joy_analysis", ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            wm.cancelUniqueWork("joy_analysis")
        }
        if (dailyReport) {
            val req = PeriodicWorkRequestBuilder<DailyReportWorker>(24, TimeUnit.HOURS).build()
            wm.enqueueUniquePeriodicWork("joy_daily_report", ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            wm.cancelUniqueWork("joy_daily_report")
        }
    }
}
