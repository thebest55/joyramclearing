package com.joyram.cleaner

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.joyram.cleaner.data.settings.SettingsStore
import com.joyram.cleaner.work.NotificationHelper
import com.joyram.cleaner.work.WorkScheduler
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class JoyApp : Application(), Configuration.Provider {
    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var settingsStore: SettingsStore
    @Inject lateinit var scheduler: WorkScheduler
    @Inject lateinit var notifier: NotificationHelper

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setWorkerFactory(workerFactory).build()

    override fun onCreate() {
        super.onCreate()
        notifier.createChannels()
        scope.launch {
            settingsStore.settings
                .map { it.scanIntervalMinutes to it.dailyReport }
                .distinctUntilChanged()
                .collect { (interval, daily) -> scheduler.apply(interval, daily) }
        }
    }
}
