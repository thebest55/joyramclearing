package com.joyram.cleaner.domain.analysis

import com.joyram.cleaner.domain.model.FileCategory
import com.joyram.cleaner.domain.model.StoredFile

object JunkDetector {
    private val junkExt = setOf("tmp", "temp", "log", "bak", "old", "crdownload", "part", "partial", "thumbdata", "dmp")

    fun isJunk(name: String, size: Long): Boolean {
        if (size == 0L) return true
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in junkExt || name.endsWith("~")
    }

    fun categoryOf(name: String, mime: String?): FileCategory {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            ext == "apk" || ext == "xapk" || ext == "apks" -> FileCategory.APK
            mime?.startsWith("image/") == true -> FileCategory.IMAGE
            mime?.startsWith("video/") == true -> FileCategory.VIDEO
            mime?.startsWith("audio/") == true -> FileCategory.AUDIO
            ext in setOf("zip", "rar", "7z", "tar", "gz") -> FileCategory.ARCHIVE
            ext in setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "epub") -> FileCategory.DOCUMENT
            else -> FileCategory.OTHER
        }
    }

    /** Marks junk files and duplicates (same name and size; the first occurrence is kept). */
    fun mark(files: List<StoredFile>): List<StoredFile> {
        val seen = HashSet<String>()
        return files.map { f ->
            val sig = f.name + "#" + f.sizeBytes
            val dup = f.sizeBytes > 0 && !seen.add(sig)
            f.copy(junk = isJunk(f.name, f.sizeBytes), duplicate = dup)
        }
    }
}
