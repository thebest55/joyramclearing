package com.joyram.cleaner.ui.screens

import android.os.BatteryManager
import android.os.PowerManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.model.CpuUsageSource
import com.joyram.cleaner.domain.model.HistoryRange

@Composable
fun healthLabel(score: Int): String = stringResource(
    when {
        score >= 80 -> R.string.health_good
        score >= 60 -> R.string.health_fair
        else -> R.string.health_poor
    },
)

@Composable
fun batteryStatusText(status: Int): String = stringResource(
    when (status) {
        BatteryManager.BATTERY_STATUS_CHARGING -> R.string.bat_status_charging
        BatteryManager.BATTERY_STATUS_DISCHARGING -> R.string.bat_status_discharging
        BatteryManager.BATTERY_STATUS_FULL -> R.string.bat_status_full
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> R.string.bat_status_not_charging
        else -> R.string.unknown
    },
)

@Composable
fun pluggedText(plugged: Int): String = stringResource(
    when (plugged) {
        BatteryManager.BATTERY_PLUGGED_AC -> R.string.plug_ac
        BatteryManager.BATTERY_PLUGGED_USB -> R.string.plug_usb
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> R.string.plug_wireless
        0 -> R.string.plug_none
        else -> R.string.unknown
    },
)

@Composable
fun batteryHealthText(health: Int): String = stringResource(
    when (health) {
        BatteryManager.BATTERY_HEALTH_GOOD -> R.string.bhealth_good
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> R.string.bhealth_overheat
        BatteryManager.BATTERY_HEALTH_DEAD -> R.string.bhealth_dead
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> R.string.bhealth_overvoltage
        BatteryManager.BATTERY_HEALTH_COLD -> R.string.bhealth_cold
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> R.string.bhealth_failure
        else -> R.string.bhealth_unknown
    },
)

@Composable
fun thermalText(status: Int?): String = stringResource(
    when (status) {
        null -> R.string.thermal_unsupported
        PowerManager.THERMAL_STATUS_NONE -> R.string.thermal_none
        PowerManager.THERMAL_STATUS_LIGHT -> R.string.thermal_light
        PowerManager.THERMAL_STATUS_MODERATE -> R.string.thermal_moderate
        PowerManager.THERMAL_STATUS_SEVERE -> R.string.thermal_severe
        PowerManager.THERMAL_STATUS_CRITICAL -> R.string.thermal_critical
        PowerManager.THERMAL_STATUS_EMERGENCY -> R.string.thermal_emergency
        else -> R.string.thermal_shutdown
    },
)

@Composable
fun rangeLabel(r: HistoryRange): String = stringResource(
    when (r) {
        HistoryRange.H1 -> R.string.range_1h
        HistoryRange.H24 -> R.string.range_24h
        HistoryRange.D7 -> R.string.range_7d
    },
)

@Composable
fun cpuSourceText(s: CpuUsageSource): String = stringResource(
    when (s) {
        CpuUsageSource.PROC_STAT -> R.string.cpu_src_stat
        CpuUsageSource.FREQUENCY -> R.string.cpu_src_freq
        CpuUsageSource.UNAVAILABLE -> R.string.cpu_src_none
    },
)
