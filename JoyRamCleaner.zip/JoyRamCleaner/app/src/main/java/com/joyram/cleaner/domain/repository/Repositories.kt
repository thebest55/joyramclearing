package com.joyram.cleaner.domain.repository

import android.net.Uri
import com.joyram.cleaner.domain.model.*
import kotlinx.coroutines.flow.Flow

interface SystemRepository {
    fun snapshotFlow(intervalMs: Long): Flow<SystemSnapshot>
    suspend fun snapshot(): SystemSnapshot
    suspend fun deviceDetails(): DeviceDetails
    /** Deletes this app's own cache files. Returns the real number of bytes freed. */
    suspend fun clearOwnCache(): Long
    suspend fun ownCacheSize(): Long
}

interface AppsRepository {
    suspend fun loadApps(): List<AppEntry>
    fun hasUsageAccess(): Boolean
}

interface StorageRepository {
    suspend fun mediaSummary(): MediaSummary
    suspend fun largestMedia(limit: Int): List<StoredFile>
    suspend fun scanTree(tree: Uri, limit: Int = 20_000): List<StoredFile>
    suspend fun deleteDocuments(files: List<StoredFile>): Int
}

interface HistoryRepository {
    fun ramSeries(since: Long): Flow<List<TimePoint>>
    fun cpuSeries(since: Long): Flow<List<TimePoint>>
    fun batteryLevelSeries(since: Long): Flow<List<TimePoint>>
    fun batteryTempSeries(since: Long): Flow<List<TimePoint>>
    fun storageFreeSeries(since: Long): Flow<List<TimePoint>>
    fun latestScan(): Flow<ScanRecord?>
    fun scans(limit: Int): Flow<List<ScanRecord>>
    fun reports(type: ReportType?, limit: Int): Flow<List<Report>>
    suspend fun record(snapshot: SystemSnapshot, force: Boolean = false)
    suspend fun saveScan(record: ScanRecord)
    suspend fun saveReport(report: Report)
    suspend fun clearAll()
}

interface CatalogRepository {
    suspend fun saveDevice(summary: DeviceSummary, kernel: String)
    suspend fun getSetting(name: String): String?
    fun observeSetting(name: String): Flow<String?>
    suspend fun putSetting(name: String, value: String)
    suspend fun removeSetting(name: String)
}
