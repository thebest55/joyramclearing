package com.joyram.cleaner.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.joyram.cleaner.BuildConfig
import com.joyram.cleaner.R
import com.joyram.cleaner.data.settings.ThemeMode
import com.joyram.cleaner.ui.components.*
import com.joyram.cleaner.ui.nav.Routes
import com.joyram.cleaner.util.MediaPermissions

@Composable
fun SettingsScreen(onNavigate: (String) -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val perm by vm.perm.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var confirmReset by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf(AppCompatDelegate.getApplicationLocales().toLanguageTags()) }

    LifecycleResumeEffect(Unit) {
        vm.refreshPermissions()
        onPauseOrDispose { }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPermissions() }
    val mediaLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.refreshPermissions() }

    fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
    }

    ScreenList {
        item { TabHeader(stringResource(R.string.settings_title)) }

        item {
            JoyCard {
                SectionTitle(stringResource(R.string.set_appearance))
                Spacer(Modifier.height(8.dp))
                ChipRow(ThemeMode.entries, s.themeMode, {
                    stringResource(
                        when (it) {
                            ThemeMode.SYSTEM -> R.string.theme_system
                            ThemeMode.LIGHT -> R.string.theme_light
                            ThemeMode.DARK -> R.string.theme_dark
                        },
                    )
                }, { vm.setTheme(it) })
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.set_language), fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                val langs = listOf("" to R.string.lang_system, "tr" to R.string.lang_tr, "en" to R.string.lang_en)
                val current = langs.firstOrNull { it.first.isNotEmpty() && lang.startsWith(it.first) }?.first ?: ""
                ChipRow(langs.map { it.first }, current, { tag -> stringResource(langs.first { it.first == tag }.second) }) { tag ->
                    lang = tag
                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
                }
            }
        }

        item {
            JoyCard {
                SectionTitle(stringResource(R.string.set_notifications))
                SwitchRow(stringResource(R.string.set_notif_enable), s.notificationsEnabled) {
                    vm.setNotifications(it)
                    if (it && !perm.notifications) requestNotifications()
                }
                if (s.notificationsEnabled) {
                    SwitchRow(stringResource(R.string.set_notif_storage), s.notifyStorage) { vm.setNotifyStorage(it) }
                    SwitchRow(stringResource(R.string.set_notif_temp), s.notifyTemp) { vm.setNotifyTemp(it) }
                    SwitchRow(stringResource(R.string.set_notif_ram), s.notifyRam) { vm.setNotifyRam(it) }
                }
                SwitchRow(stringResource(R.string.set_daily_report), s.dailyReport) { vm.setDaily(it) }
            }
        }

        item {
            JoyCard {
                SectionTitle(stringResource(R.string.set_auto_analysis))
                Spacer(Modifier.height(8.dp))
                ChipRow(listOf(0, 15, 30, 60, 180, 360, 720, 1440), s.scanIntervalMinutes, {
                    when {
                        it == 0 -> stringResource(R.string.interval_off)
                        it < 60 -> "$it min"
                        else -> "${it / 60} h"
                    }
                }, { vm.setInterval(it) })
                Spacer(Modifier.height(6.dp))
                NoteText(stringResource(R.string.set_auto_note))
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.set_retention), fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                ChipRow(listOf(1, 7, 30, 90), s.retentionDays, { stringResource(R.string.days_fmt, it) }, { vm.setRetention(it) })
            }
        }

        item {
            JoyCard {
                SectionTitle(stringResource(R.string.set_permissions))
                Spacer(Modifier.height(6.dp))
                PermRow(stringResource(R.string.perm_notifications), perm.notifications) { requestNotifications() }
                PermRow(stringResource(R.string.perm_media), perm.media) { mediaLauncher.launch(MediaPermissions.required()) }
                PermRow(stringResource(R.string.perm_usage), perm.usageAccess) { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                NoteText(stringResource(R.string.perm_note))
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }) { Text(stringResource(R.string.perm_open_settings)) }
            }
        }

        item {
            JoyCard {
                SectionTitle(stringResource(R.string.set_privacy))
                TextButton(onClick = { onNavigate(Routes.PRIVACY) }) { Text(stringResource(R.string.privacy_title)) }
                TextButton(onClick = { onNavigate(Routes.HISTORY) }) { Text(stringResource(R.string.history_title)) }
                OutlinedButton(
                    onClick = { confirmReset = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.Delete, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.set_reset))
                }
            }
        }

        item {
            JoyCard {
                SectionTitle(stringResource(R.string.set_about))
                InfoRow(stringResource(R.string.app_name), stringResource(R.string.app_tagline))
                InfoRow(stringResource(R.string.set_version), "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
                NoteText(stringResource(R.string.about_body))
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text(stringResource(R.string.set_reset)) },
            text = { Text(stringResource(R.string.set_reset_confirm)) },
            confirmButton = { TextButton(onClick = { vm.resetAll(); confirmReset = false }) { Text(stringResource(R.string.reset), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(label: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label)
            NoteText(stringResource(if (granted) R.string.perm_granted else R.string.perm_not_granted))
        }
        if (!granted) TextButton(onClick = onGrant) { Text(stringResource(R.string.grant_access)) }
        else Icon(Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.secondary)
    }
}
