@file:OptIn(ExperimentalMaterial3Api::class)

package com.joyram.cleaner.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.model.Insight
import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.Severity
import com.joyram.cleaner.domain.model.TimePoint
import com.joyram.cleaner.ui.theme.Amber
import com.joyram.cleaner.ui.theme.Green
import com.joyram.cleaner.ui.theme.Red

@Composable
fun JoyCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val shape = RoundedCornerShape(20.dp)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = shape, colors = colors) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(modifier = modifier.fillMaxWidth(), shape = shape, colors = colors) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier.padding(top = 4.dp), style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
}

@Composable
fun TabHeader(title: String) {
    Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground)
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Text(value, fontWeight = FontWeight.Medium, textAlign = TextAlign.End, modifier = Modifier.weight(1.4f))
    }
}

@Composable
fun NoteText(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun GaugeRing(percent: Int, label: String, modifier: Modifier = Modifier, size: Dp = 120.dp, color: Color = MaterialTheme.colorScheme.secondary) {
    val animated by animateFloatAsState(targetValue = percent.coerceIn(0, 100) / 100f, label = "gauge")
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val stroke = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
            drawArc(track, 135f, 270f, false, style = stroke)
            drawArc(color, 135f, 270f * animated, false, style = stroke)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$percent", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun LineChart(
    points: List<TimePoint>,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    minY: Float? = null,
    maxY: Float? = null,
    unit: String = "",
) {
    if (points.size < 2) {
        Box(modifier.fillMaxWidth().height(110.dp), contentAlignment = Alignment.Center) {
            NoteText(stringResource(R.string.chart_collecting))
        }
        return
    }
    val lo0 = minY ?: points.minOf { it.v }
    val hi0 = maxY ?: points.maxOf { it.v }
    val lo = if (hi0 - lo0 < 1f) lo0 - 1f else lo0
    val hi = if (hi0 - lo0 < 1f) hi0 + 1f else hi0
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    Column(modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val w = size.width
            val h = size.height
            for (i in 0..2) {
                val y = h * i / 2f
                drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
            }
            val t0 = points.first().t.toFloat()
            val span = (points.last().t - points.first().t).toFloat().coerceAtLeast(1f)
            fun x(p: TimePoint) = (p.t - t0) / span * w
            fun y(p: TimePoint) = h - ((p.v - lo) / (hi - lo)) * h
            val line = Path()
            points.forEachIndexed { i, p -> if (i == 0) line.moveTo(x(p), y(p)) else line.lineTo(x(p), y(p)) }
            val fill = Path().apply {
                addPath(line)
                lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent)))
            drawPath(line, color, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round))
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            NoteText("min %.0f%s".format(points.minOf { it.v }, unit))
            NoteText("max %.0f%s".format(points.maxOf { it.v }, unit))
        }
    }
}

data class Segment(val fraction: Float, val color: Color)

@Composable
fun SegmentedBar(segments: List<Segment>, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    Canvas(modifier.fillMaxWidth().height(16.dp)) {
        drawRoundRect(track, size = size, cornerRadius = CornerRadius(8.dp.toPx()))
        var x = 0f
        segments.forEach { s ->
            val w = size.width * s.fraction.coerceIn(0f, 1f)
            if (w > 0f) drawRect(s.color, Offset(x, 0f), Size(w, size.height))
            x += w
        }
    }
}

@Composable
fun StatBar(percent: Int, modifier: Modifier = Modifier) {
    val color = when {
        percent >= 90 -> Red
        percent >= 75 -> Amber
        else -> MaterialTheme.colorScheme.secondary
    }
    LinearProgressIndicator(
        progress = { percent.coerceIn(0, 100) / 100f },
        modifier = modifier.fillMaxWidth().height(8.dp),
        color = color, trackColor = MaterialTheme.colorScheme.surfaceVariant,
        strokeCap = StrokeCap.Round, gapSize = 0.dp, drawStopIndicator = {},
    )
}

@Composable
fun EmptyState(icon: ImageVector, text: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

@Composable
fun <T> ChipRow(options: List<T>, selected: T, label: @Composable (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
        }
    }
}

@Composable
fun InsightCard(insight: Insight) {
    val primary = MaterialTheme.colorScheme.primary
    val (icon, tint) = when {
        insight.severity == Severity.CRITICAL -> Icons.Filled.Error to Red
        insight.severity == Severity.WARNING -> Icons.Filled.Warning to Amber
        insight.id == InsightId.ALL_GOOD -> Icons.Filled.CheckCircle to Green
        else -> Icons.Filled.Info to primary
    }
    JoyCard {
        Row(verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(stringResource(insight.title), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(stringResource(insight.body, *insight.args.toTypedArray()), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.suggestion_prefix) + " " + stringResource(insight.action),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary,
                )
            }
        }
    }
}

@Composable
fun ScreenList(inner: PaddingValues = PaddingValues(), content: LazyListScope.() -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(inner),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
fun SubScreen(
    title: String,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        content = content,
    )
}
