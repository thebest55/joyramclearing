package com.joyram.cleaner.data.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import com.joyram.cleaner.data.db.*
import com.joyram.cleaner.data.settings.SettingsStore
import com.joyram.cleaner.data.system.AppsSource
import com.joyram.cleaner.data.system.SystemMetricsSource
import com.joyram.cleaner.domain.analysis.JunkDetector
import com.joyram.cleaner.domain.model.*
import com.joyram.cleaner.domain.repository.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SystemRepositoryImpl @Inject constructor(private val source: SystemMetricsSource) : SystemRepository {
    override fun snapshotFlow(intervalMs: Long): Flow<SystemSnapshot> = flow {
        while (true) {
            emit(source.readSnapshot())
            delay(intervalMs)
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun snapshot(): SystemSnapshot = withContext(Dispatchers.IO) {
        // CPU usage needs two samples to compute a delta
        source.readCpu()
        delay(250)
        source.readSnapshot()
    }

    override suspend fun deviceDetails(): DeviceDetails = withContext(Dispatchers.IO) { source.readDeviceDetails() }
    override suspend fun clearOwnCache(): Long = withContext(Dispatchers.IO) { source.clearOwnCache() }
    override suspend fun ownCacheSize(): Long = withContext(Dispatchers.IO) { source.ownCacheSize() }
}

@Singleton
class AppsRepositoryImpl @Inject constructor(
    private val source: AppsSource,
    private val dao: CatalogDao,
) : AppsRepository {
    override suspend fun loadApps(): List<AppEntry> = withContext(Dispatchers.IO) {
        val apps = source.load()
        dao.replaceApps(
            apps.map {
                AppInfoEntity(it.packageName, it.label, it.versionName, it.isSystem, it.installTime, it.updateTime,
                    it.apkSizeBytes, it.lastUsed, it.canLaunch)
            },
        )
        apps
    }

    override fun hasUsageAccess(): Boolean = source.hasUsageAccess()
}

@Singleton
class HistoryRepositoryImpl @Inject constructor(
    private val dao: HistoryDao,
    private val settings: SettingsStore,
) : HistoryRepository {
    @Volatile private var lastRecord = 0L
    @Volatile private var lastPrune = 0L

    override fun ramSeries(since: Long) = dao.ram(since).map { l -> l.map { TimePoint(it.timestamp, it.usedPercent.toFloat()) } }
    override fun cpuSeries(since: Long) = dao.cpu(since).map { l ->
        l.filter { it.usagePercent >= 0 }.map { TimePoint(it.timestamp, it.usagePercent.toFloat()) }
    }
    override fun batteryLevelSeries(since: Long) = dao.battery(since).map { l -> l.map { TimePoint(it.timestamp, it.level.toFloat()) } }
    override fun batteryTempSeries(since: Long) = dao.battery(since).map { l -> l.map { TimePoint(it.timestamp, it.tempC) } }
    override fun storageFreeSeries(since: Long) = dao.storage(since).map { l ->
        l.filter { it.totalBytes > 0 }.map { TimePoint(it.timestamp, it.freeBytes * 100f / it.totalBytes) }
    }

    override fun latestScan() = dao.latestScan().map { e -> e?.let { ScanRecord(it.timestamp, it.healthScore, it.issueCount, it.durationMs) } }
    override fun scans(limit: Int) = dao.scans(limit).map { l -> l.map { ScanRecord(it.timestamp, it.healthScore, it.issueCount, it.durationMs) } }

    override fun reports(type: ReportType?, limit: Int): Flow<List<Report>> =
        (if (type == null) dao.allReports(limit) else dao.reportsOfType(type.name, limit)).map { l -> l.map { it.toDomain() } }

    override suspend fun record(snapshot: SystemSnapshot, force: Boolean) {
        val now = snapshot.timestamp
        if (!force && now - lastRecord < 30_000) return
        lastRecord = now
        val freqs = snapshot.cpu.curFreqKhz.filterNotNull()
        dao.recordAll(
            RamHistoryEntity(timestamp = now, totalBytes = snapshot.ram.totalBytes, availBytes = snapshot.ram.availBytes, usedPercent = snapshot.ram.usedPercent),
            CpuHistoryEntity(timestamp = now, usagePercent = snapshot.cpu.usagePercent ?: -1, appCpuPercent = snapshot.cpu.appCpuPercent,
                avgFreqMhz = if (freqs.isEmpty()) 0 else (freqs.average() / 1000).toInt()),
            BatteryHistoryEntity(timestamp = now, level = snapshot.battery.levelPercent, tempC = snapshot.battery.tempC,
                voltageMv = snapshot.battery.voltageMv, charging = snapshot.battery.isCharging),
            StorageHistoryEntity(timestamp = now, totalBytes = snapshot.storage.totalBytes, freeBytes = snapshot.storage.freeBytes),
        )
        if (now - lastPrune > 600_000) {
            lastPrune = now
            val days = settings.settings.first().retentionDays
            dao.pruneAll(now - days * 86_400_000L)
        }
    }

    override suspend fun saveScan(record: ScanRecord) =
        dao.insertScan(ScanHistoryEntity(timestamp = record.timestamp, healthScore = record.healthScore, issueCount = record.issueCount, durationMs = record.durationMs))

    override suspend fun saveReport(report: Report) = dao.insertReport(
        PerformanceReportEntity(
            timestamp = report.timestamp, type = report.type.name, healthScore = report.healthScore,
            ramPercent = report.ramPercent, storageFreePercent = report.storageFreePercent,
            batteryTempC = report.batteryTempC, batteryLevel = report.batteryLevel, cpuPercent = report.cpuPercent,
            issueIds = report.issueIds, refPackage = report.refPackage, durationMs = report.durationMs,
            ramPercentStart = report.ramPercentStart, tempStartC = report.tempStartC,
        ),
    )

    override suspend fun clearAll() = withContext(Dispatchers.IO) {
        lastRecord = 0L
        dao.pruneAll(Long.MAX_VALUE)
    }

    private fun PerformanceReportEntity.toDomain() = Report(
        id, timestamp, runCatching { ReportType.valueOf(type) }.getOrDefault(ReportType.SCAN), healthScore,
        ramPercent, storageFreePercent, batteryTempC, batteryLevel, cpuPercent, issueIds, refPackage, durationMs,
        ramPercentStart, tempStartC,
    )
}

@Singleton
class CatalogRepositoryImpl @Inject constructor(private val dao: CatalogDao) : CatalogRepository {
    override suspend fun saveDevice(summary: DeviceSummary, kernel: String) =
        dao.upsertDevice(DeviceInfoEntity(1, summary.brand, summary.model, summary.androidRelease, summary.sdk, kernel, System.currentTimeMillis()))

    override suspend fun getSetting(name: String) = dao.getSetting(name)
    override fun observeSetting(name: String) = dao.observeSetting(name)
    override suspend fun putSetting(name: String, value: String) = dao.putSetting(UserSettingEntity(name, value))
    override suspend fun removeSetting(name: String) = dao.removeSetting(name)
}

@Singleton
class StorageRepositoryImpl @Inject constructor(@ApplicationContext private val ctx: Context) : StorageRepository {
    private val resolver: ContentResolver get() = ctx.contentResolver
    private val images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private val videos = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    private val audios = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

    override suspend fun mediaSummary(): MediaSummary = withContext(Dispatchers.IO) {
        val (ib, ic) = sum(images)
        val (vb, vc) = sum(videos)
        val (ab, ac) = sum(audios)
        MediaSummary(ib, ic, vb, vc, ab, ac)
    }

    private fun sum(uri: Uri): Pair<Long, Int> = try {
        resolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { c ->
            var total = 0L
            var n = 0
            while (c.moveToNext()) { total += c.getLong(0); n++ }
            total to n
        } ?: (0L to 0)
    } catch (_: SecurityException) { 0L to 0 }

    override suspend fun largestMedia(limit: Int): List<StoredFile> = withContext(Dispatchers.IO) {
        (query(images, FileCategory.IMAGE, limit) + query(videos, FileCategory.VIDEO, limit) + query(audios, FileCategory.AUDIO, limit))
            .sortedByDescending { it.sizeBytes }.take(limit)
    }

    private fun query(collection: Uri, cat: FileCategory, limit: Int): List<StoredFile> = try {
        val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_MODIFIED)
        val out = ArrayList<StoredFile>()
        resolver.query(collection, proj, null, null, "${MediaStore.MediaColumns.SIZE} DESC")?.use { c ->
            while (c.moveToNext() && out.size < limit) {
                out += StoredFile(
                    uri = ContentUris.withAppendedId(collection, c.getLong(0)),
                    name = c.getString(1).orEmpty(), sizeBytes = c.getLong(2), mime = c.getString(3),
                    modified = c.getLong(4) * 1000, source = FileSource.MEDIA, category = cat,
                )
            }
        }
        JunkDetector.mark(out)
    } catch (_: SecurityException) { emptyList() }

    override suspend fun scanTree(tree: Uri, limit: Int): List<StoredFile> = withContext(Dispatchers.IO) {
        val out = ArrayList<StoredFile>()
        val stack = ArrayDeque<Pair<String, Int>>()
        stack.add(DocumentsContract.getTreeDocumentId(tree) to 0)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        while (stack.isNotEmpty() && out.size < limit) {
            ensureActive()
            val (id, depth) = stack.removeLast()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            try {
                resolver.query(children, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val docId = c.getString(0)
                        val name = c.getString(1).orEmpty()
                        val mime = c.getString(2)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            if (depth < 8) stack.add(docId to depth + 1)
                        } else {
                            out += StoredFile(
                                uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId), name = name,
                                sizeBytes = if (c.isNull(3)) 0L else c.getLong(3), mime = mime,
                                modified = if (c.isNull(4)) 0L else c.getLong(4), source = FileSource.TREE,
                                category = JunkDetector.categoryOf(name, mime),
                            )
                        }
                    }
                }
            } catch (_: Exception) { /* unreadable folder: skip */ }
        }
        JunkDetector.mark(out)
    }

    override suspend fun deleteDocuments(files: List<StoredFile>): Int = withContext(Dispatchers.IO) {
        files.count { f ->
            try { DocumentsContract.deleteDocument(resolver, f.uri) } catch (_: Exception) { false }
        }
    }
}
