package com.joyram.cleaner.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Navy = Color(0xFF0A1128)
val NavySurface = Color(0xFF111B3A)
val Blue = Color(0xFF3B82F6)
val Cyan = Color(0xFF22D3EE)
val Amber = Color(0xFFF59E0B)
val Red = Color(0xFFEF4444)
val Green = Color(0xFF22C55E)

private val DarkColors = darkColorScheme(
    primary = Blue, onPrimary = Color.White,
    secondary = Cyan, onSecondary = Navy,
    background = Navy, onBackground = Color(0xFFF1F5F9),
    surface = NavySurface, onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1B2850), onSurfaceVariant = Color(0xFFB6C2DD),
    error = Red, outline = Color(0xFF3A4A78),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB), onPrimary = Color.White,
    secondary = Color(0xFF0891B2), onSecondary = Color.White,
    background = Color(0xFFF3F6FB), onBackground = Color(0xFF0F172A),
    surface = Color.White, onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE5EAF3), onSurfaceVariant = Color(0xFF334155),
    error = Color(0xFFDC2626), outline = Color(0xFF94A3B8),
)

@Composable
fun JoyTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        shapes = Shapes(medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(20.dp)),
        content = content,
    )
}
