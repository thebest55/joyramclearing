package com.joyram.cleaner.di

import android.content.Context
import androidx.room.Room
import com.joyram.cleaner.data.db.CatalogDao
import com.joyram.cleaner.data.db.HistoryDao
import com.joyram.cleaner.data.db.JoyDatabase
import com.joyram.cleaner.data.repository.*
import com.joyram.cleaner.domain.repository.*
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DbModule {
    @Provides @Singleton
    fun db(@ApplicationContext ctx: Context): JoyDatabase =
        Room.databaseBuilder(ctx, JoyDatabase::class.java, "joy_ram_cleaner.db").build()

    @Provides fun historyDao(db: JoyDatabase): HistoryDao = db.historyDao()
    @Provides fun catalogDao(db: JoyDatabase): CatalogDao = db.catalogDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepoModule {
    @Binds abstract fun system(impl: SystemRepositoryImpl): SystemRepository
    @Binds abstract fun apps(impl: AppsRepositoryImpl): AppsRepository
    @Binds abstract fun history(impl: HistoryRepositoryImpl): HistoryRepository
    @Binds abstract fun catalog(impl: CatalogRepositoryImpl): CatalogRepository
    @Binds abstract fun storage(impl: StorageRepositoryImpl): StorageRepository
}
