package com.joyram.cleaner.data.system

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import com.joyram.cleaner.domain.model.AppEntry
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppsSource @Inject constructor(@ApplicationContext private val ctx: Context) {

    fun hasUsageAccess(): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun load(): List<AppEntry> {
        val pm = ctx.packageManager
        val packages: List<PackageInfo> = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(0)
        }
        val usage: Map<String, Long> = if (hasUsageAccess()) {
            val usm = ctx.getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            usm.queryAndAggregateUsageStats(now - 90L * 86_400_000L, now)
                .mapValues { it.value.lastTimeUsed }
        } else emptyMap()

        return packages.mapNotNull { p ->
            val ai = p.applicationInfo ?: return@mapNotNull null
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            var size = File(ai.sourceDir.orEmpty()).length()
            ai.splitSourceDirs?.forEach { size += File(it).length() }
            AppEntry(
                packageName = p.packageName,
                label = pm.getApplicationLabel(ai).toString(),
                versionName = p.versionName.orEmpty(),
                isSystem = system,
                installTime = p.firstInstallTime,
                updateTime = p.lastUpdateTime,
                apkSizeBytes = size,
                lastUsed = usage[p.packageName]?.takeIf { it > 0 },
                canLaunch = pm.getLaunchIntentForPackage(p.packageName) != null,
            )
        }.sortedBy { it.label.lowercase() }
    }
}
