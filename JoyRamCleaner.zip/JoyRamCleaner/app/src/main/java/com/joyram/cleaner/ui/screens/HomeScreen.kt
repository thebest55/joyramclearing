package com.joyram.cleaner.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.analysis.AnalysisEngine
import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.ScanStage
import com.joyram.cleaner.domain.model.SystemSnapshot
import com.joyram.cleaner.ui.components.*
import com.joyram.cleaner.ui.nav.Routes
import com.joyram.cleaner.util.Fmt

private data class Module(val route: String, val icon: ImageVector, val label: Int)

@Composable
fun HomeScreen(onNavigate: (String) -> Unit, vm: HomeViewModel = hiltViewModel()) {
    val snap by vm.snapshot.collectAsStateWithLifecycle()
    val last by vm.lastScan.collectAsStateWithLifecycle()
    val scan by vm.scanState.collectAsStateWithLifecycle()
    val s = snap

    val modules = listOf(
        Module(Routes.RAM, Icons.Filled.Memory, R.string.mod_ram),
        Module(Routes.CPU, Icons.Filled.Speed, R.string.mod_cpu),
        Module(Routes.STORAGE, Icons.Filled.Storage, R.string.mod_storage),
        Module(Routes.BATTERY, Icons.Filled.BatteryFull, R.string.mod_battery),
        Module(Routes.APPS, Icons.Filled.Apps, R.string.mod_apps),
        Module(Routes.GAME, Icons.Filled.SportsEsports, R.string.mod_game),
        Module(Routes.DEVICE, Icons.Filled.PhoneAndroid, R.string.mod_device),
        Module(Routes.ANALYZER, Icons.Filled.Insights, R.string.mod_analyzer),
        Module(Routes.HISTORY, Icons.Filled.History, R.string.mod_history),
    )

    ScreenList {
        item {
            Column {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.app_tagline), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (s == null) {
            item { LoadingBox() }
        } else {
            item { HealthCard(s, last?.timestamp, scan, onScan = vm::startScan) }
            item { RamHomeCard(s) { onNavigate(Routes.RAM) } }
            item { StorageHomeCard(s) { onNavigate(Routes.STORAGE) } }
            item { BatteryHomeCard(s) { onNavigate(Routes.BATTERY) } }
            item { CpuHomeCard(s) { onNavigate(Routes.CPU) } }
            item { DeviceHomeCard(s) { onNavigate(Routes.DEVICE) } }
            item { SectionTitle(stringResource(R.string.home_alerts)) }
            items(AnalysisEngine.analyze(s)) { InsightCard(it) }
        }
        item { SectionTitle(stringResource(R.string.home_modules)) }
        items(modules.chunked(3)) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { m ->
                    Card(
                        onClick = { onNavigate(m.route) },
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Column(Modifier.padding(vertical = 16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(m.icon, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(stringResource(m.label), style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }

    (scan as? ScanUi.Done)?.let { st ->
        AlertDialog(
            onDismissRequest = vm::dismiss,
            title = { Text(stringResource(R.string.scan_done_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(R.string.scan_done_score, st.result.healthScore, healthLabel(st.result.healthScore)))
                    val issues = st.result.insights.count { it.id != InsightId.ALL_GOOD }
                    Text(stringResource(R.string.scan_done_issues, issues))
                    Text(stringResource(R.string.scan_done_apps, st.result.appCount))
                    Text(stringResource(R.string.scan_done_time, st.result.durationMs))
                }
            },
            confirmButton = { TextButton(onClick = { vm.dismiss(); onNavigate(Routes.ANALYZER) }) { Text(stringResource(R.string.view_report)) } },
            dismissButton = { TextButton(onClick = vm::dismiss) { Text(stringResource(R.string.close)) } },
        )
    }
}

@Composable
private fun HealthCard(s: SystemSnapshot, lastScan: Long?, scan: ScanUi, onScan: () -> Unit) {
    val score = AnalysisEngine.healthScore(s)
    JoyCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GaugeRing(score, stringResource(R.string.health_score_label))
            Spacer(Modifier.width(16.dp))
            Column {
                Text(stringResource(R.string.device_health), style = MaterialTheme.typography.titleMedium)
                Text(healthLabel(score), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(4.dp))
                NoteText(
                    stringResource(R.string.last_analysis) + ": " +
                        (lastScan?.let { Fmt.dateTime(it) } ?: stringResource(R.string.never)),
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        val running = scan as? ScanUi.Running
        Button(
            onClick = onScan, enabled = running == null,
            modifier = Modifier.fillMaxWidth().height(56.dp),
        ) {
            Icon(Icons.Filled.Search, null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.system_scan), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        if (running != null) {
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { (running.stage.ordinal + 1) / 4f }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            NoteText(
                stringResource(
                    when (running.stage) {
                        ScanStage.SNAPSHOT -> R.string.scan_stage_snapshot
                        ScanStage.APPS -> R.string.scan_stage_apps
                        ScanStage.ANALYZE -> R.string.scan_stage_analyze
                        ScanStage.SAVE -> R.string.scan_stage_save
                    },
                ),
            )
        }
        if (scan is ScanUi.Failed) {
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.scan_failed), color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun RamHomeCard(s: SystemSnapshot, onClick: () -> Unit) {
    JoyCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.mod_ram), fontWeight = FontWeight.SemiBold)
            Text("${s.ram.usedPercent}%", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        StatBar(s.ram.usedPercent)
        Spacer(Modifier.height(8.dp))
        NoteText(stringResource(R.string.ram_summary, Fmt.bytes(s.ram.totalBytes), Fmt.bytes(s.ram.availBytes)))
    }
}

@Composable
private fun StorageHomeCard(s: SystemSnapshot, onClick: () -> Unit) {
    JoyCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.mod_storage), fontWeight = FontWeight.SemiBold)
            Text("${s.storage.usedPercent}%", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        StatBar(s.storage.usedPercent)
        Spacer(Modifier.height(8.dp))
        NoteText(stringResource(R.string.storage_summary, Fmt.bytes(s.storage.totalBytes), Fmt.bytes(s.storage.usedBytes), Fmt.bytes(s.storage.freeBytes)))
    }
}

@Composable
private fun BatteryHomeCard(s: SystemSnapshot, onClick: () -> Unit) {
    JoyCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.mod_battery), fontWeight = FontWeight.SemiBold)
            Text("${s.battery.levelPercent}%", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        InfoRow(stringResource(R.string.bat_temp), Fmt.temp(s.battery.tempC))
        InfoRow(stringResource(R.string.bat_status), batteryStatusText(s.battery.status))
    }
}

@Composable
private fun CpuHomeCard(s: SystemSnapshot, onClick: () -> Unit) {
    JoyCard(onClick = onClick) {
        Text(stringResource(R.string.mod_cpu), fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        InfoRow(stringResource(R.string.cpu_model), s.cpu.model)
        InfoRow(stringResource(R.string.cpu_cores), s.cpu.cores.toString())
        InfoRow(
            stringResource(R.string.cpu_usage),
            s.cpu.usagePercent?.let { "$it%" } ?: stringResource(R.string.not_supported),
        )
    }
}

@Composable
private fun DeviceHomeCard(s: SystemSnapshot, onClick: () -> Unit) {
    JoyCard(onClick = onClick) {
        InfoRow(stringResource(R.string.dev_model), "${s.device.brand} ${s.device.model}")
        InfoRow(stringResource(R.string.dev_android), "${s.device.androidRelease} (API ${s.device.sdk})")
    }
}
