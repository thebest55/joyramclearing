package com.joyram.cleaner.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.model.AppEntry
import com.joyram.cleaner.ui.components.*
import com.joyram.cleaner.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) {
            try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (_: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size)) else Spacer(Modifier.size(size))
}

@Composable
fun AppsScreen(onBack: () -> Unit, vm: AppsViewModel = hiltViewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var detail by remember { mutableStateOf<AppEntry?>(null) }
    val visible = ui.visible

    SubScreen(stringResource(R.string.apps_title), onBack, actions = {
        IconButton(onClick = vm::load) { Icon(Icons.Filled.Refresh, stringResource(R.string.refresh)) }
    }) { inner ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                OutlinedTextField(
                    value = ui.query, onValueChange = vm::setQuery, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    placeholder = { Text(stringResource(R.string.search)) },
                )
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChipRow(AppFilter.entries, ui.filter, { stringResource(appFilterLabel(it)) }, vm::setFilter)
                    ChipRow(AppSort.entries, ui.sort, { stringResource(appSortLabel(it)) }, vm::setSort)
                }
            }
            if (!ui.usageAccess && (ui.filter == AppFilter.UNUSED || ui.sort == AppSort.LAST_USED)) {
                item {
                    JoyCard {
                        Text(stringResource(R.string.apps_usage_why))
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) {
                            Text(stringResource(R.string.open_usage_access))
                        }
                    }
                }
            }
            item { NoteText(stringResource(R.string.apps_visibility_note)) }
            if (ui.loading) {
                item { LoadingBox() }
            } else if (visible.isEmpty()) {
                item { EmptyState(Icons.Filled.Apps, stringResource(R.string.apps_empty)) }
            } else {
                item { NoteText(stringResource(R.string.apps_count, visible.size)) }
                items(visible, key = { it.packageName }) { app ->
                    JoyCard(onClick = { detail = app }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(app.packageName)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(app.label, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                NoteText(app.packageName)
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(Fmt.bytes(app.apkSizeBytes), style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }

    detail?.let { app ->
        AlertDialog(
            onDismissRequest = { detail = null },
            icon = { AppIcon(app.packageName, 48.dp) },
            title = { Text(app.label) },
            text = {
                Column {
                    InfoRow(stringResource(R.string.app_package), app.packageName)
                    InfoRow(stringResource(R.string.app_version), app.versionName.ifBlank { "—" })
                    InfoRow(stringResource(R.string.app_type), stringResource(if (app.isSystem) R.string.app_type_system else R.string.app_type_user))
                    InfoRow(stringResource(R.string.app_size), Fmt.bytes(app.apkSizeBytes))
                    InfoRow(stringResource(R.string.app_installed), Fmt.date(app.installTime))
                    InfoRow(stringResource(R.string.app_updated), Fmt.date(app.updateTime))
                    InfoRow(
                        stringResource(R.string.app_last_used),
                        app.lastUsed?.let { Fmt.date(it) }
                            ?: stringResource(if (ui.usageAccess) R.string.app_not_used_90 else R.string.not_available),
                    )
                    NoteText(stringResource(R.string.app_size_note))
                    Spacer(Modifier.height(8.dp))
                    if (app.canLaunch) {
                        TextButton(onClick = {
                            ctx.packageManager.getLaunchIntentForPackage(app.packageName)?.let { ctx.startActivity(it) }
                        }) { Text(stringResource(R.string.app_open)) }
                    }
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
                    }) { Text(stringResource(R.string.app_permissions)) }
                    if (!app.isSystem) {
                        TextButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
                            detail = null
                        }) { Text(stringResource(R.string.app_uninstall), color = MaterialTheme.colorScheme.error) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detail = null }) { Text(stringResource(R.string.close)) } },
        )
    }
}

private fun appFilterLabel(f: AppFilter) = when (f) {
    AppFilter.USER -> R.string.filter_user
    AppFilter.SYSTEM -> R.string.filter_system
    AppFilter.ALL -> R.string.filter_all
    AppFilter.UNUSED -> R.string.filter_unused
}

private fun appSortLabel(s: AppSort) = when (s) {
    AppSort.NAME -> R.string.sort_name
    AppSort.SIZE -> R.string.sort_size
    AppSort.INSTALL -> R.string.sort_install
    AppSort.LAST_USED -> R.string.sort_last_used
}
