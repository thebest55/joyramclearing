package com.joyram.cleaner.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.joyram.cleaner.R
import com.joyram.cleaner.domain.model.Severity
import com.joyram.cleaner.ui.components.*
import com.joyram.cleaner.util.Fmt

@Composable
fun GameScreen(onBack: () -> Unit, vm: GameViewModel = hiltViewModel()) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val session by vm.session.collectAsStateWithLifecycle()
    val reports by vm.reports.collectAsStateWithLifecycle()
    val pre by vm.preCheck.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var picking by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) }
    val labels = remember(apps) { apps.associate { it.packageName to it.label } }

    SubScreen(stringResource(R.string.game_title), onBack) { inner ->
        ScreenList(inner) {
            session?.let { s ->
                item {
                    JoyCard {
                        Text(stringResource(R.string.game_session_active), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                        Text(labels[s.packageName] ?: s.packageName)
                        NoteText(stringResource(R.string.game_session_since, Fmt.dateTime(s.startTime)))
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = vm::endSession) {
                                Icon(Icons.Filled.Stop, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.game_end_session))
                            }
                            TextButton(onClick = vm::cancelSession) { Text(stringResource(R.string.cancel)) }
                        }
                    }
                }
            }
            item {
                JoyCard {
                    Text(stringResource(R.string.game_dnd_title), fontWeight = FontWeight.SemiBold)
                    NoteText(stringResource(R.string.game_dnd_body))
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)) }) {
                        Text(stringResource(R.string.game_dnd_open))
                    }
                    Spacer(Modifier.height(6.dp))
                    NoteText(stringResource(R.string.game_no_boost_note))
                }
            }
            item { SectionTitle(stringResource(R.string.game_my_games)) }
            val myGames = apps.filter { it.packageName in selected }
            if (myGames.isEmpty()) {
                item { EmptyState(Icons.Filled.SportsEsports, stringResource(R.string.game_empty)) }
            } else {
                items(myGames, key = { it.packageName }) { app ->
                    JoyCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(app.packageName)
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Button(onClick = { pending = app.packageName; vm.runPreCheck() }, enabled = session == null) {
                                Icon(Icons.Filled.PlayArrow, null)
                                Spacer(Modifier.width(4.dp))
                                Text(stringResource(R.string.game_analyze_play))
                            }
                        }
                    }
                }
            }
            item {
                OutlinedButton(onClick = { picking = !picking }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Apps, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(if (picking) R.string.game_done_picking else R.string.game_pick))
                }
            }
            if (picking) {
                if (loading) item { LoadingBox() }
                items(apps, key = { "pick_" + it.packageName }) { app ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = app.packageName in selected, onCheckedChange = { vm.toggle(app.packageName) })
                        AppIcon(app.packageName, 32.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            item { SectionTitle(stringResource(R.string.game_history)) }
            if (reports.isEmpty()) {
                item { NoteText(stringResource(R.string.game_history_empty)) }
            } else {
                items(reports, key = { it.id }) { r ->
                    JoyCard {
                        Text(labels[r.refPackage] ?: r.refPackage.orEmpty(), fontWeight = FontWeight.SemiBold)
                        NoteText(Fmt.dateTime(r.timestamp) + " · " + Fmt.duration(r.durationMs))
                        InfoRow(stringResource(R.string.mod_ram), "${r.ramPercentStart}% → ${r.ramPercent}%")
                        InfoRow(stringResource(R.string.bat_temp), "${Fmt.temp(r.tempStartC)} → ${Fmt.temp(r.batteryTempC)}")
                        InfoRow(stringResource(R.string.mod_battery), "${r.batteryLevel}%")
                        if (r.cpuPercent >= 0) InfoRow(stringResource(R.string.cpu_usage), "${r.cpuPercent}%")
                    }
                }
            }
        }
    }

    pending?.let { pkg ->
        val result = pre
        AlertDialog(
            onDismissRequest = { pending = null; vm.dismissPreCheck() },
            title = { Text(stringResource(R.string.game_precheck_title)) },
            text = {
                if (result == null) {
                    LoadingBox()
                } else {
                    val s = result.snapshot
                    val problems = result.insights.filter { it.severity != Severity.INFO }
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        InfoRow(stringResource(R.string.ram_available), Fmt.bytes(s.ram.availBytes) + " (${100 - s.ram.usedPercent}%)")
                        InfoRow(stringResource(R.string.cpu_usage), s.cpu.usagePercent?.let { "$it%" } ?: stringResource(R.string.not_supported))
                        InfoRow(stringResource(R.string.bat_temp), Fmt.temp(s.battery.tempC))
                        InfoRow(stringResource(R.string.storage_free), Fmt.bytes(s.storage.freeBytes))
                        Spacer(Modifier.height(6.dp))
                        if (problems.isEmpty()) {
                            Text(stringResource(R.string.game_ready), color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold)
                        } else {
                            Text(stringResource(R.string.game_attention), fontWeight = FontWeight.SemiBold)
                            problems.forEach { Text("• " + stringResource(it.action), style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = result != null,
                    onClick = {
                        vm.startSession(pkg)
                        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
                        pending = null; vm.dismissPreCheck()
                    },
                ) { Text(stringResource(R.string.game_start)) }
            },
            dismissButton = { TextButton(onClick = { pending = null; vm.dismissPreCheck() }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
