package com.joyram.cleaner

import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.ReportType
import com.joyram.cleaner.domain.model.ScanStage
import com.joyram.cleaner.domain.usecase.ScanSystemUseCase
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

class ScanSystemUseCaseTest {
    private val system = FakeSystemRepository()
    private val apps = FakeAppsRepository()
    private val history = FakeHistoryRepository()
    private val catalog = FakeCatalogRepository()
    private fun useCase() = ScanSystemUseCase(system, apps, history, catalog)

    @Test fun persistTrueSavesRecordScanAndReport() = runTest {
        val stages = mutableListOf<ScanStage>()
        val r = useCase()(persist = true, type = ReportType.DAILY, onStage = { stages += it })
        assertEquals(listOf(ScanStage.SNAPSHOT, ScanStage.APPS, ScanStage.ANALYZE, ScanStage.SAVE), stages)
        assertEquals(1, history.recorded.size)
        assertEquals(1, history.scansSaved.size)
        assertEquals(1, history.reportsSaved.size)
        assertEquals(ReportType.DAILY, history.reportsSaved.first().type)
        assertEquals(r.healthScore, history.scansSaved.first().healthScore)
        assertEquals(1, catalog.deviceSaved)
    }

    @Test fun persistFalseWritesNothing() = runTest {
        useCase()(persist = false)
        assertTrue(history.recorded.isEmpty())
        assertTrue(history.scansSaved.isEmpty())
        assertTrue(history.reportsSaved.isEmpty())
    }

    @Test fun appStatsAreComputedFromRealList() = runTest {
        apps.usageAccess = true
        apps.apps = listOf(
            TestData.app("old.app", updatedDaysAgo = 400, installedDaysAgo = 500),
            TestData.app("fresh.app", updatedDaysAgo = 5, installedDaysAgo = 10, lastUsedDaysAgo = 1),
            TestData.app("system.app", system = true, updatedDaysAgo = 900, installedDaysAgo = 900),
        )
        val r = useCase()(persist = false)
        assertEquals(3, r.appCount)
        assertEquals(1, r.stats.staleCount)
        assertEquals(1, r.stats.unusedCount)
        assertTrue(r.insights.any { it.id == InsightId.OUTDATED_APPS })
    }

    @Test fun unusedIsUnknownWithoutUsageAccess() = runTest {
        apps.usageAccess = false
        apps.apps = listOf(TestData.app("a", installedDaysAgo = 500))
        val r = useCase()(persist = false)
        assertNull(r.stats.unusedCount)
        assertFalse(r.insights.any { it.id == InsightId.UNUSED_APPS })
    }

    @Test fun appLoadFailureDoesNotBreakTheScan() = runTest {
        apps.fail = true
        val r = useCase()(persist = true)
        assertEquals(0, r.appCount)
        assertEquals(1, history.scansSaved.size)
    }
}
