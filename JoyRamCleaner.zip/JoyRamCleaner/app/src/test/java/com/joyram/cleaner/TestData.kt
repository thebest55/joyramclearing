package com.joyram.cleaner

import android.os.BatteryManager
import com.joyram.cleaner.domain.model.*
import com.joyram.cleaner.domain.repository.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf

object TestData {
    /** Builds a snapshot with exactly the requested percentages (total = 1000 units). */
    fun snapshot(
        ramUsedPct: Int = 50,
        lowMemory: Boolean = false,
        storageFreePct: Int = 50,
        tempC: Float = 30f,
        cpu: Int? = 20,
        thermal: Int? = null,
        timestamp: Long = 1_000L,
    ): SystemSnapshot {
        val total = 1000L
        return SystemSnapshot(
            timestamp = timestamp,
            ram = RamInfo(total, total - ramUsedPct * 10L, 100, lowMemory, 50_000_000),
            cpu = CpuInfo(
                "TestSoC", "arm64-v8a", 8, List(8) { 1_000_000L }, List(8) { 2_000_000L }, cpu,
                if (cpu == null) CpuUsageSource.UNAVAILABLE else CpuUsageSource.PROC_STAT, 1, thermal, null,
            ),
            battery = BatteryInfo(80, tempC, 4000, BatteryManager.BATTERY_STATUS_DISCHARGING, 0, "Li-ion", BatteryManager.BATTERY_HEALTH_GOOD, null),
            storage = StorageInfo(total, storageFreePct * 10L),
            device = DeviceSummary("Brand", "Model", "14", 34),
        )
    }

    fun app(
        pkg: String, label: String = pkg, system: Boolean = false,
        installedDaysAgo: Int = 100, updatedDaysAgo: Int = 10, lastUsedDaysAgo: Int? = null, size: Long = 1_000,
    ): AppEntry {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        return AppEntry(
            pkg, label, "1.0", system, now - installedDaysAgo * day, now - updatedDaysAgo * day, size,
            lastUsedDaysAgo?.let { now - it * day }, canLaunch = true,
        )
    }
}

class FakeSystemRepository(var snap: SystemSnapshot = TestData.snapshot(), var fail: Boolean = false) : SystemRepository {
    override fun snapshotFlow(intervalMs: Long): Flow<SystemSnapshot> = flowOf(snap)
    override suspend fun snapshot(): SystemSnapshot = if (fail) throw IllegalStateException("boom") else snap
    override suspend fun deviceDetails(): DeviceDetails = throw UnsupportedOperationException()
    override suspend fun clearOwnCache(): Long = 0L
    override suspend fun ownCacheSize(): Long = 0L
}

class FakeAppsRepository(
    var apps: List<AppEntry> = emptyList(),
    var usageAccess: Boolean = false,
    var fail: Boolean = false,
) : AppsRepository {
    override suspend fun loadApps(): List<AppEntry> = if (fail) throw IllegalStateException("apps") else apps
    override fun hasUsageAccess(): Boolean = usageAccess
}

class FakeHistoryRepository : HistoryRepository {
    val recorded = mutableListOf<SystemSnapshot>()
    val scansSaved = mutableListOf<ScanRecord>()
    val reportsSaved = mutableListOf<Report>()
    var cleared = false

    override fun ramSeries(since: Long): Flow<List<TimePoint>> = flowOf(emptyList())
    override fun cpuSeries(since: Long): Flow<List<TimePoint>> = flowOf(emptyList())
    override fun batteryLevelSeries(since: Long): Flow<List<TimePoint>> = flowOf(emptyList())
    override fun batteryTempSeries(since: Long): Flow<List<TimePoint>> = flowOf(emptyList())
    override fun storageFreeSeries(since: Long): Flow<List<TimePoint>> = flowOf(emptyList())
    override fun latestScan(): Flow<ScanRecord?> = flowOf(null)
    override fun scans(limit: Int): Flow<List<ScanRecord>> = flowOf(emptyList())
    override fun reports(type: ReportType?, limit: Int): Flow<List<Report>> = flowOf(emptyList())
    override suspend fun record(snapshot: SystemSnapshot, force: Boolean) { recorded += snapshot }
    override suspend fun saveScan(record: ScanRecord) { scansSaved += record }
    override suspend fun saveReport(report: Report) { reportsSaved += report }
    override suspend fun clearAll() { cleared = true }
}

class FakeCatalogRepository : CatalogRepository {
    val settings = mutableMapOf<String, String>()
    var deviceSaved = 0
    override suspend fun saveDevice(summary: DeviceSummary, kernel: String) { deviceSaved++ }
    override suspend fun getSetting(name: String): String? = settings[name]
    override fun observeSetting(name: String): Flow<String?> = MutableStateFlow(settings[name])
    override suspend fun putSetting(name: String, value: String) { settings[name] = value }
    override suspend fun removeSetting(name: String) { settings.remove(name) }
}
