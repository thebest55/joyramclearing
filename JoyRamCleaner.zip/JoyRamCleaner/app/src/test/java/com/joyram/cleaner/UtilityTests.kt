package com.joyram.cleaner

import com.joyram.cleaner.domain.analysis.JunkDetector
import com.joyram.cleaner.domain.model.FileCategory
import com.joyram.cleaner.domain.model.TimePoint
import com.joyram.cleaner.ui.screens.chargeRatePerHour
import com.joyram.cleaner.util.Fmt
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.Locale

class FmtTest {
    @Before fun locale() { Locale.setDefault(Locale.US) }

    @Test fun bytesFormatting() {
        assertEquals("0 B", Fmt.bytes(0))
        assertEquals("1023 B", Fmt.bytes(1023))
        assertEquals("1.0 KB", Fmt.bytes(1024))
        assertEquals("1.5 MB", Fmt.bytes(1_572_864))
        assertEquals("2.0 GB", Fmt.bytes(2L * 1024 * 1024 * 1024))
    }

    @Test fun durationFormatting() {
        assertEquals("0m", Fmt.duration(0))
        assertEquals("1h 30m", Fmt.duration(90 * 60_000L))
        assertEquals("2d 3h 5m", Fmt.duration(2 * 86_400_000L + 3 * 3_600_000L + 5 * 60_000L))
    }

    @Test fun temperatureAndFrequency() {
        assertEquals("36.5 °C", Fmt.temp(36.5f))
        assertEquals("1800 MHz", Fmt.mhz(1_800_000L))
        assertEquals("—", Fmt.mhz(null))
    }
}

class JunkDetectorTest {
    @Test fun junkDetection() {
        assertTrue(JunkDetector.isJunk("cache.tmp", 10))
        assertTrue(JunkDetector.isJunk("movie.part", 10))
        assertTrue(JunkDetector.isJunk("empty.txt", 0))
        assertTrue(JunkDetector.isJunk("notes.txt~", 5))
        assertFalse(JunkDetector.isJunk("photo.jpg", 100))
    }

    @Test fun categories() {
        assertEquals(FileCategory.APK, JunkDetector.categoryOf("a.apk", null))
        assertEquals(FileCategory.IMAGE, JunkDetector.categoryOf("a.jpg", "image/jpeg"))
        assertEquals(FileCategory.VIDEO, JunkDetector.categoryOf("a.mp4", "video/mp4"))
        assertEquals(FileCategory.AUDIO, JunkDetector.categoryOf("a.mp3", "audio/mpeg"))
        assertEquals(FileCategory.ARCHIVE, JunkDetector.categoryOf("a.zip", "application/zip"))
        assertEquals(FileCategory.DOCUMENT, JunkDetector.categoryOf("a.pdf", "application/pdf"))
        assertEquals(FileCategory.OTHER, JunkDetector.categoryOf("a.bin", null))
    }
}

class ChargeRateTest {
    @Test fun needsAtLeastTenMinutes() {
        assertNull(chargeRatePerHour(emptyList()))
        assertNull(chargeRatePerHour(listOf(TimePoint(0, 50f))))
        assertNull(chargeRatePerHour(listOf(TimePoint(0, 50f), TimePoint(5 * 60_000L, 52f))))
    }

    @Test fun computesPercentPerHour() {
        val r = chargeRatePerHour(listOf(TimePoint(0, 50f), TimePoint(30 * 60_000L, 55f)))
        assertEquals(10f, r!!, 0.001f)
        val d = chargeRatePerHour(listOf(TimePoint(0, 80f), TimePoint(60 * 60_000L, 77f)))
        assertEquals(-3f, d!!, 0.001f)
    }
}
