package com.joyram.cleaner

import com.joyram.cleaner.domain.usecase.ScanSystemUseCase
import com.joyram.cleaner.ui.screens.AppFilter
import com.joyram.cleaner.ui.screens.AppSort
import com.joyram.cleaner.ui.screens.AppsViewModel
import com.joyram.cleaner.ui.screens.HomeViewModel
import com.joyram.cleaner.ui.screens.ScanUi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModelTest {
    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    @Test fun scanEndsInDoneState() = runTest {
        val history = FakeHistoryRepository()
        val uc = ScanSystemUseCase(FakeSystemRepository(), FakeAppsRepository(), history, FakeCatalogRepository())
        val vm = HomeViewModel(FakeSystemRepository(), history, uc)
        assertTrue(vm.scanState.value is ScanUi.Idle)
        vm.startScan()
        val state = vm.scanState.value
        assertTrue("state was $state", state is ScanUi.Done)
        assertEquals(1, history.scansSaved.size)
        vm.dismiss()
        assertTrue(vm.scanState.value is ScanUi.Idle)
    }

    @Test fun failedScanShowsFailedState() = runTest {
        val failing = FakeSystemRepository(fail = true)
        val uc = ScanSystemUseCase(failing, FakeAppsRepository(), FakeHistoryRepository(), FakeCatalogRepository())
        val vm = HomeViewModel(failing, FakeHistoryRepository(), uc)
        vm.startScan()
        assertTrue(vm.scanState.value is ScanUi.Failed)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class AppsViewModelTest {
    @Before fun setUp() { Dispatchers.setMain(UnconfinedTestDispatcher()) }
    @After fun tearDown() { Dispatchers.resetMain() }

    private fun repo() = FakeAppsRepository(
        apps = listOf(
            TestData.app("com.a.game", "Alpha", size = 300),
            TestData.app("com.b.tool", "Beta", size = 100, lastUsedDaysAgo = 2),
            TestData.app("com.android.sys", "System", system = true, size = 900),
        ),
        usageAccess = true,
    )

    @Test fun loadsAndFiltersUserApps() = runTest {
        val vm = AppsViewModel(repo())
        assertFalse(vm.ui.value.loading)
        assertEquals(listOf("com.a.game", "com.b.tool"), vm.ui.value.visible.map { it.packageName })
        vm.setFilter(AppFilter.SYSTEM)
        assertEquals(listOf("com.android.sys"), vm.ui.value.visible.map { it.packageName })
        vm.setFilter(AppFilter.ALL)
        assertEquals(3, vm.ui.value.visible.size)
    }

    @Test fun searchAndSort() = runTest {
        val vm = AppsViewModel(repo())
        vm.setFilter(AppFilter.ALL)
        vm.setQuery("bet")
        assertEquals(listOf("com.b.tool"), vm.ui.value.visible.map { it.packageName })
        vm.setQuery("")
        vm.setSort(AppSort.SIZE)
        assertEquals("com.android.sys", vm.ui.value.visible.first().packageName)
    }

    @Test fun unusedFilterUsesRealLastUsedValues() = runTest {
        val vm = AppsViewModel(repo())
        vm.setFilter(AppFilter.UNUSED)
        assertEquals(listOf("com.a.game"), vm.ui.value.visible.map { it.packageName })
    }

    @Test fun loadFailureEndsWithEmptyList() = runTest {
        val vm = AppsViewModel(FakeAppsRepository(fail = true))
        assertFalse(vm.ui.value.loading)
        assertTrue(vm.ui.value.apps.isEmpty())
    }
}
