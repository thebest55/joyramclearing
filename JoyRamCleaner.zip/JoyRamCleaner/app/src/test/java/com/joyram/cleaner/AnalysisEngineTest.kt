package com.joyram.cleaner

import android.os.PowerManager
import com.joyram.cleaner.domain.analysis.AnalysisEngine
import com.joyram.cleaner.domain.model.AppStats
import com.joyram.cleaner.domain.model.InsightId
import com.joyram.cleaner.domain.model.Severity
import org.junit.Assert.*
import org.junit.Test

class AnalysisEngineTest {
    private fun ids(s: com.joyram.cleaner.domain.model.SystemSnapshot, stats: AppStats = AppStats()) =
        AnalysisEngine.analyze(s, stats).map { it.id }

    @Test fun healthyDeviceHasOnlyAllGoodAndFullScore() {
        val s = TestData.snapshot()
        assertEquals(listOf(InsightId.ALL_GOOD), ids(s))
        assertEquals(100, AnalysisEngine.healthScore(s))
    }

    @Test fun criticalStorageIsCritical() {
        val r = AnalysisEngine.analyze(TestData.snapshot(storageFreePct = 5))
        assertEquals(InsightId.STORAGE_CRITICAL, r.first().id)
        assertEquals(Severity.CRITICAL, r.first().severity)
    }

    @Test fun lowStorageIsWarning() {
        val r = AnalysisEngine.analyze(TestData.snapshot(storageFreePct = 15))
        assertEquals(InsightId.STORAGE_LOW, r.first().id)
        assertEquals(Severity.WARNING, r.first().severity)
    }

    @Test fun batteryTemperatureLevels() {
        assertEquals(Severity.WARNING, AnalysisEngine.analyze(TestData.snapshot(tempC = 41f)).first().severity)
        assertEquals(Severity.CRITICAL, AnalysisEngine.analyze(TestData.snapshot(tempC = 46f)).first().severity)
        assertFalse(InsightId.BATTERY_HOT in ids(TestData.snapshot(tempC = 39f)))
    }

    @Test fun ramLevels() {
        assertEquals(Severity.WARNING, AnalysisEngine.analyze(TestData.snapshot(ramUsedPct = 85)).first().severity)
        assertEquals(Severity.CRITICAL, AnalysisEngine.analyze(TestData.snapshot(ramUsedPct = 92)).first().severity)
        assertTrue(InsightId.LOW_MEMORY in ids(TestData.snapshot(lowMemory = true)))
        assertFalse(InsightId.RAM_HIGH in ids(TestData.snapshot(ramUsedPct = 60)))
    }

    @Test fun unavailableCpuNeverCreatesAnInsight() {
        assertEquals(listOf(InsightId.ALL_GOOD), ids(TestData.snapshot(cpu = null)))
    }

    @Test fun highCpuCreatesInsight() {
        assertTrue(InsightId.CPU_HIGH in ids(TestData.snapshot(cpu = 90)))
    }

    @Test fun thermalStatusMapsToSeverity() {
        val moderate = AnalysisEngine.analyze(TestData.snapshot(thermal = PowerManager.THERMAL_STATUS_MODERATE)).first()
        val severe = AnalysisEngine.analyze(TestData.snapshot(thermal = PowerManager.THERMAL_STATUS_SEVERE)).first()
        assertEquals(Severity.WARNING, moderate.severity)
        assertEquals(Severity.CRITICAL, severe.severity)
        assertFalse(InsightId.THERMAL in ids(TestData.snapshot(thermal = PowerManager.THERMAL_STATUS_LIGHT)))
    }

    @Test fun appStatsProduceInsightsOnlyWhenKnown() {
        val s = TestData.snapshot()
        assertTrue(InsightId.OUTDATED_APPS in ids(s, AppStats(staleCount = 3)))
        assertTrue(InsightId.UNUSED_APPS in ids(s, AppStats(unusedCount = 2)))
        assertFalse(InsightId.UNUSED_APPS in ids(s, AppStats(unusedCount = null)))
        assertFalse(InsightId.UNUSED_APPS in ids(s, AppStats(unusedCount = 0)))
    }

    @Test fun insightsAreSortedBySeverity() {
        val r = AnalysisEngine.analyze(TestData.snapshot(storageFreePct = 5, ramUsedPct = 85), AppStats(staleCount = 1))
        assertEquals(r.sortedByDescending { it.severity.ordinal }.map { it.id }, r.map { it.id })
    }

    @Test fun scoreDropsForProblemsAndStaysInRange() {
        val healthy = AnalysisEngine.healthScore(TestData.snapshot())
        val bad = AnalysisEngine.healthScore(
            TestData.snapshot(ramUsedPct = 99, lowMemory = true, storageFreePct = 1, tempC = 60f, cpu = 100, thermal = PowerManager.THERMAL_STATUS_SEVERE),
        )
        assertTrue(bad < healthy)
        assertTrue(bad in 0..100)
    }
}
