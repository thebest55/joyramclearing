# JOY RAM Cleaner – Advanced Android System Manager

RAM, CPU, pil, depolama, uygulamalar ve cihaz bilgilerini tek yerden analiz eden, **tamamen çevrimdışı** çalışan bir Android uygulaması.
Kotlin · Jetpack Compose · Material 3 · Clean Architecture + MVVM · Hilt · Room · DataStore · WorkManager.

> **Derleme durumu (lütfen okuyun):** Bu proje, Android SDK ve Google Maven erişimi olmayan bir ortamda yazıldı.
> Kod bu ortamda **derlenmedi, APK üretilmedi ve testler çalıştırılmadı**. Yalnızca yapısal denetimler yapıldı
> (parantez dengesi, paket adı/klasör uyumu, kullanılan 331 metnin Türkçe ve İngilizce dosyalarda bulunması, XML geçerliliği).
> İlk derlemede küçük hatalar çıkabilir; aşağıdaki adımlarla Android Studio'da derleyip testleri çalıştırın.

## Gereksinimler
- Android Studio Koala (2024.1.1) veya daha yenisi
- JDK 17 (Android Studio ile gelir)
- Android SDK 34 (compileSdk/targetSdk 34, minSdk 26 = Android 8.0)
- Gradle 8.9 (wrapper indirir), AGP 8.5.2, Kotlin 2.0.20

## Debug APK derleme
```bash
./gradlew assembleDebug
# çıktı: app/build/outputs/apk/debug/app-debug.apk
```
Android Studio'da: `File > Open` ile bu klasörü açın, Gradle Sync bitince `Run ▶` veya `Build > Build APK(s)`.

> `./gradlew` açılmazsa Android Studio'nun kendi Gradle'ı ile Sync yapın ya da `gradle wrapper --gradle-version 8.9` ile wrapper'ı yenileyin.

## İmzalı release APK
1. Anahtar deposu oluşturun (bir kez):
   ```bash
   keytool -genkeypair -v -keystore joyram-release.jks -alias joyram \
     -keyalg RSA -keysize 2048 -validity 10000
   ```
2. `keystore.properties.example` dosyasını `keystore.properties` olarak kopyalayıp doldurun
   (`storeFile`, `storePassword`, `keyAlias`, `keyPassword`). Bu dosya ve `.jks` `.gitignore` içindedir; **asla paylaşmayın**.
3. Derleyin:
   ```bash
   ./gradlew assembleRelease
   # çıktı: app/build/outputs/apk/release/app-release.apk
   ```
4. İmzayı doğrulayın:
   ```bash
   apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
   ```
Google Play için `./gradlew bundleRelease` ile AAB üretebilirsiniz.

## Testler
```bash
./gradlew testDebugUnitTest            # JVM: analiz motoru, yardımcılar, use case, ViewModel testleri
./gradlew connectedDebugAndroidTest    # cihaz/emülatör: Room, repository, izin, API uyumluluk, Compose UI testleri
```
| Tür | Dosya |
|---|---|
| Unit | `AnalysisEngineTest`, `UtilityTests` (Fmt, JunkDetector, şarj hızı) |
| Repository / use case | `ScanSystemUseCaseTest` (sahte repository'lerle), `HistoryRepositoryTest` (gerçek Room) |
| ViewModel | `ViewModelTests` (Home, Apps) |
| Database | `DatabaseTest` (Room in-memory) |
| UI | `ComponentsUiTest` (Compose) |
| Permission | `PermissionTest` |
| Android API uyumluluğu | `SystemApiCompatibilityTest` (gerçek RAM, pil, depolama, CPU, uygulama listesi) |

Gerçek cihazda RAM, pil, depolama ve uygulama yöneticisi doğrulaması için `SystemApiCompatibilityTest` çalıştırılmalı, ardından uygulama elle gezilmelidir.

## Mimari
```
domain/   model, repository arayüzleri, AnalysisEngine (kural tabanlı), ScanSystemUseCase
data/     system (Android API okuyucular), db (Room), repository (uygulamalar), settings (DataStore)
di/       Hilt modülleri
work/     WorkManager işleri + bildirimler
ui/       theme, components, nav, screens (+ ViewModel'ler)
```
Room tabloları: `DeviceInfo, RamHistory, CpuHistory, BatteryHistory, StorageHistory, ScanHistory, AppInfo, UserSettings, PerformanceReport`.

## Modüller
Home (SYSTEM SCAN, sağlık puanı, uyarılar) · RAM · CPU · Storage · Battery · Apps · Game · Device · Analyzer · History · Settings · Gizlilik politikası.
Alt gezinme: Home, RAM, Storage, Battery, Settings. Diğer modüllere Home ekranından erişilir.

## Android sınırları – uygulamanın dürüst davranışı
| İstenen | Gerçek durum | Uygulamada yapılan |
|---|---|---|
| Başka uygulamaların RAM kullanımı | Android uygulamalara vermez | Yalnızca kendi PSS değeri gösterilir, açıklama notu vardır |
| RAM temizleme / uygulama kapatma | Güvenilir ve izinli yol yok | Hiçbir uygulama kapatılmaz; yalnızca **kendi önbelleği** silinir ve **gerçekten silinen bayt** raporlanır |
| Toplam CPU kullanımı | Android 8+ `/proc/stat` erişimini engelleyebilir | Okunabiliyorsa gösterilir; değilse frekans oranından *tahmin* (kaynağı belirtilir) ya da "desteklenmiyor" |
| Pil sağlığı yüzdesi | API yok | Sadece Android'in bildirdiği durum (İyi, Aşırı ısınma vb.); yüzde tahmin edilmez |
| GPU modeli | Grafik bağlamı olmadan yok | OpenGL ES sürümü gösterilir |
| FPS artırma, GPU hızlandırma, overclock | Yetki yok | Yapılmaz; ekranda açıkça yazılır. Oyun öncesi kontrol ve oyun sonrası rapor sunulur |
| Uygulama boyutları | Veri/önbellek boyutu başkalarına kapalı | Kurulu APK boyutu gösterilir |
| Tüm paketleri listeleme | `QUERY_ALL_PACKAGES` Play politikası gerektirir | Kullanılmaz; yalnızca başlatıcıda görünen uygulamalar listelenir |
| Kesintisiz arka plan takibi | Doze/pil sınırları | WorkManager ile periyodik (en az 15 dk) analiz; gerçek zamanlı takip vaat edilmez |
| Başka uygulamaların dosyalarını silme | Yasak | Yalnızca kullanıcının seçtiği klasör (SAF) ve MediaStore silme onayı (Android 11+) |

## İzinler
`POST_NOTIFICATIONS` (uyarılar) · `READ_MEDIA_*` / `READ_EXTERNAL_STORAGE ≤32` (medya analizi) ·
`PACKAGE_USAGE_STATS` (isteğe bağlı, kullanılmayan uygulamalar; kullanıcı sistem ayarından verir) · `REQUEST_DELETE_PACKAGES` (sistem kaldırma onayı).
**İnternet izni yoktur**, root gerekmez, hiçbir veri cihazdan çıkmaz.

## Dil ve tema
Türkçe ve İngilizce (`values/`, `values-tr/`), uygulama içinden değiştirilebilir (Android 13+ sistem dil ayarıyla da uyumlu). Koyu / Açık / Sistem teması.
